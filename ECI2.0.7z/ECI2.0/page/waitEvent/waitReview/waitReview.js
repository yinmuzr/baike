//获取用户信息及视图权限
var view = new viewAuthor(['muchPass']);
var usermess = view.getUserMessage();
window.onload = function(){
    view.judgeViewAuthor();
}

layui.use(['form','table','laydate'],function(){
    var form = layui.form;
    var table = layui.table;

    var loadIndex = layer.load(1,{
      shade:[0.1,'#fff']
    });
    var waitReview=table.render({
        elem: '#waitReview',
        url:baseURL_zcw + '/expert/getList',
        headers:{
          token:usermess.token
        },
        where:{
          flag: "WAIT_AUDIT",
        },
        method:'post',
        contentType:'application/json',
        id:'waitReview',
        cellMinWidth:150,
        // even:true,
        page:{theme:'#1E9FFF'},
        cols: [[ //表头                             
          {type:'checkbox',fixed:'left'},
          {title: '<span style="color:#000;font-weight:bold;">序号</span>',width:80,templet:function(d){ 
            return d.LAY_INDEX;
          }},
          {field: 'createTime', title: '<span style="color:#000;font-weight:bold;">录入日期</span>',},
          {field: 'name', title: '<span style="color:#000;font-weight:bold;">姓名</span>'},
          {field: '',title:'<span style="color:#000;font-weight:bold;">详情</span>',toolbar:'#detail',},  
          {field: 'rejectReason',title:'<span style="color:#000;font-weight:bold;">驳回原因</span>',edit:'text'},                                              
          {field: '',title:'<span style="color:#000;font-weight:bold;">操作</span>',width:300,toolbar:'#waitReviewToolBar',},                   
        ]],
          response:{                                         //定义后端Json格式
              statusCode:0,
              msgName:"msg",
              dataName:"data",
              countName:'amount'
          },
          request:{
              limitName:'size'
          },
          done:function(res,curr,count){
              layer.close(loadIndex);
              if(!/5/g.test(usermess.viewAuthor)){          //动态添加驳回原因
                $('#waitReview').next().find('th[data-field="rejectReason"]').css('display','none');
                $('#waitReview').next().find('td[data-field="rejectReason"]').css('display','none');
              }
            }
    });

    //监听工具栏
    table.on('tool(waitReview)',function(obj){
        var data = obj.data;
        var layEvent = obj.event;
        var tr = obj.tr;
        var communicationTheme = data.communicationTheme;

        if(layEvent == 'detail'){
            if(communicationTheme==undefined){    //录入类型--人员
                IFrame.open('../../person/personEntry.html',obj);
            }
            else{                               //录入类型--活动
                IFrame.open('../../activity/activityEntry.html',obj);
            }
        }
        else if(layEvent == 'modify'){
            if(communicationTheme==undefined){    
                IFrame.open('../../person/personEntry.html',obj);
            }
            else{                             
                IFrame.open('../../activity/activityEntry.html',obj);
            }
        }
        else if(layEvent == 'pass'){
            if(communicationTheme==undefined){   
                var Data = {
                    ids:[],
                    flag:'pass'
                };
                Data.ids[0]=data.id;
                $.ajax({
                    url:baseURL_zcw + '/expert/audit',
                    type:'POST',
                    headers:{
                        token:usermess.token
                    },
                    dataType:'json',
                    cache:false,
                    contentType:'application/json',
                    data:JSON.stringify(Data),
                    success:function(res){
                        if(res.code == 0){
                            layer.msg('审核成功');
                            waitReview.reload();
                        }else{
                            layer.msg('审核失败');
                        }
                    }
                });
            }
            else{                             
                var Data = {
                    ids:[]
                };
                Data.ids[0]=data.id;
                $.ajax({
                    url:baseURL_lbq + '/activity/passActivity',
                    type:'POST',
                    headers:{
                        token:usermess.token
                    },
                    dataType:'json',
                    cache:false,
                    contentType:'application/json',
                    data:JSON.stringify(Data),
                    success:function(res){
                        if(res.code == 0){
                            layer.msg('审核成功');
                            waitReview.reload();
                        }else{
                            layer.msg('审核失败');
                        }
                    }
                });
            }
        }
        else if(layEvent == 'reject'){
            if(communicationTheme==undefined){   
                var Data = {
                    ids:[],
                    flag:'reject',
                    reason:data.rejectReason
                };
                Data.ids[0]=data.id;
                $.ajax({
                    url:baseURL_zcw + '/expert/audit',
                    type:'POST',
                    headers:{
                        token:usermess.token
                    },
                    dataType:'json',
                    cache:false,
                    contentType:'application/json',
                    data:JSON.stringify(Data),
                    success:function(res){
                        if(res.code == 0){
                            layer.msg('驳回成功');
                            waitReview.reload();
                        }else{
                            layer.msg('驳回失败');
                        }
                    }
                });
            }
            else{                             
                var Data = {
                    id:data.id,
                    rejectInfo:data.rejectReason
                };
                $.ajax({
                    url:baseURL_lbq + '/activity/rejectActivity',
                    type:'POST',
                    headers:{
                        token:usermess.token
                    },
                    dataType:'json',
                    cache:false,
                    contentType:'application/json',
                    data:JSON.stringify(Data),
                    success:function(res){
                        if(res.code == 0){
                            layer.msg('驳回成功');
                            waitReview.reload();
                        }else{
                            layer.msg('驳回失败');
                        }
                    }
                });  
            }
        }
    });

    //选择录入类型
    form.on('select(inputType)',function(obj){
        if(obj.value == '人员'){
            waitReview.reload({
                url:baseURL_zcw + '/expert/getList',
                where:{
                    flag: "WAIT_AUDIT",
                },
                cols: [[ //表头                             
                    {type:'checkbox',fixed:'left'},
                    {title: '<span style="color:#000;font-weight:bold;">序号</span>',width:80,templet:function(d){ 
                      return d.LAY_INDEX;
                    }},
                    {field: 'createTime', title: '<span style="color:#000;font-weight:bold;">录入日期</span>',},
                    {field: 'name', title: '<span style="color:#000;font-weight:bold;">姓名</span>'},
                    {field: '',title:'<span style="color:#000;font-weight:bold;">详情</span>',width:150,toolbar:'#detail',},
                    {field: 'rejectReason',title:'<span style="color:#000;font-weight:bold;">驳回原因</span>',edit:'text'},                             
                    {field: '',title:'<span style="color:#000;font-weight:bold;">操作</span>',toolbar:'#waitReviewToolBar',},                   
                  ]]
            });
        }
        else if(obj.value == '活动'){
            waitReview.reload({
                url:baseURL_zcw + '/activity/getActivitiesByParams',
                where:{
                    auditStatus: 0,
                },
                cols: [[ //表头                             
                    {type:'checkbox',fixed:'left'},
                    {title: '<span style="color:#000;font-weight:bold;">序号</span>',width:80,templet:function(d){ 
                      return d.LAY_INDEX;
                    }},
                    {field: 'createTime', title: '<span style="color:#000;font-weight:bold;">录入日期</span>',},
                    {field: 'communicationTheme', title: '<span style="color:#000;font-weight:bold;">交流主题</span>'},
                    {field: '',title:'<span style="color:#000;font-weight:bold;">详情</span>',width:150,toolbar:'#detail',},         
                    {field: 'rejectReason',title:'<span style="color:#000;font-weight:bold;">驳回原因</span>',edit:'text'},                                                 
                    {field: '',title:'<span style="color:#000;font-weight:bold;">操作</span>',toolbar:'#waitReviewToolBar',},                   
                ]]
            });
        }
        return false;
    });

    //批量通过
    form.on('submit(muchPass)',function(obj){
        var checkStatus = table.checkStatus('waitReview');
        var data = checkStatus.data;
        var inputType = $('#inputType').val();
        if(inputType == '人员'){   
            var Data = {
                ids:[],
                flag:'pass'
            };
            $.each(data,function(index,value){
                Data.ids.push(value.id);
            });
            $.ajax({
                url:baseURL_zcw + '/expert/audit',
                type:'POST',
                headers:{
                    token:usermess.token
                },
                dataType:'json',
                cache:false,
                contentType:'application/json',
                data:JSON.stringify(Data),
                success:function(res){
                    if(res.code == 0){
                        layer.msg('批量审核成功');
                        waitReview.reload();
                    }else{
                        layer.msg('批量审核失败');
                    }
                }
            });
        }
        else{                             
            var Data = {
                ids:[]
            };
            $.each(data,function(index,value){
                Data.ids.push(value.id);
            });
            $.ajax({
                url:baseURL_lbq + '/activity/passActivity',
                type:'POST',
                headers:{
                    token:usermess.token
                },
                dataType:'json',
                cache:false,
                contentType:'application/json',
                data:JSON.stringify(Data),
                success:function(res){
                    if(res.code == 0){
                        layer.msg('批量审核成功');
                        waitReview.reload();
                    }else{
                        layer.msg('批量审核失败');
                    }
                }
            });
        }
        return false;
    });
});



