//获取用户信息以及视图权限
var view = new viewAuthor(['','orgExcel','muchDelete']);
var usermess = view.getUserMessage();
window.onload = function(){                   //需要将所用资源加载完毕才能获取到模板引擎（toolBar）
    view.judgeViewAuthor();
};

layui.use(['form','layer','laydate','table','laytpl','laypage'],function(){
    var form = layui.form,
        layer = parent.layer === undefined ? layui.layer : top.layer,
        $ = layui.jquery,layer = layui.layer,
        table = layui.table;

    //渲染列表
    var tableIns = table.render({
        elem: '#newsList',
        // url : '../../json/newsList.json',
        url : uploadurl+'/organization/getOrganizationsByParams',
        method:'post',
        request:{
            limitName:'size'
        },
        response:{
            countName:'amount'
        },
        headers:{
            token:token
        },
        even:true,
        contentType:'application/json',
        cellMinWidth : 95,
        page : true,
        height : 'full',
        id:'newsListTable',
        cols : [[
            {type: "checkbox", fixed:"left"},
            {type: 'numbers', title: '序号', width:60, align:"center"},
            {field: 'submitterEmail', title: '提交人'},
            {field: 'submitterDepartment', title: '提交部门', align:'center'},
            {field: 'submitterOffice', title: '提交科室',  align:'center'},
            {field: 'name', title: '组织名称', align:'center',sort:'true'},
            {field: 'primeBusiness', title: '核心业务'},
            {field: 'type', title: '组织级别', align:'center'},
            {field: 'level', title: '组织类别',  align:'center'},
            {field: 'newsLook', title: '单位地址', align:'center',width:120,templet:function(d){
                var address=new Array();
                address+=d.country;
                if(d.province!=""){
                    address+="/"+d.province;
                }
                if(d.city!="") {
                    address+="/"+d.city;
                }
                address+="-"+d.detail;
                return address;
            }},
            {field: 'companyEngaged', title: '我司是否入会', align:'center',width:120,templet:'#companyEngageddata'},
            {field: 'companyLevel', title: '我司在该组织的会员级别',  align:'center'},
            {field: 'companyTerm', title: '我司在该组织的任期', align:'center'},
            {field: 'leaderEngaged', title: '我司人员是否任职',  align:'center',templet:'#leaderEngageddata',width:150},
            {field: 'leaderName', title: '我司任职人员名称', align:'center'},
            {field: 'leaderJob', title: '我司任职人员职务',  align:'center'},
            {field: 'leaderTerm', title: '我司任职人员任期', align:'center',width:120},
            {field: 'remark', title: '备注', align:'center'},
            {field: 'legalPerson', title: '法人',  align:'center'},
            {field: 'assign', title: '指派人', align:'center',width:120,templet:function (d) {
                return '<span class="layui-red">'+d.assign+'</span>'
            }},
            {title: '操作', width:140, templet:'#orgToolBar',fixed:"right",align:"center"}
        ]],
    });

  //  搜索【此功能需要后台配合，所以暂时没有动态效果演示】
    $(".search_btn").on("click",function(){
        // if($(".searchVal")[0].value != ''||$(".searchVal")[1].value||$(".searchVal")[2].value||$(".searchVal")[3].value){
            table.reload("newsListTable",{
                page: {
                    curr: 1 //重新从第 1 页开始
                },
                where: {
                    companyEngaged:$("#companyEngaged").val(),
                    leaderEngaged:$("#leaderEngaged").val(),
                    name:$("#name").val().replace(/(^\s*)|(\s*$)/g,""),
                    type:$("#type").val(),
                    submitterDepartment:$("[name='submitterDepartment']").parent()[0].innerText,
                    primeBusiness:$("#primeBusiness").val()
                }
            })
        // }else{
        //     layer.msg("请输入搜索的内容");
        // }
    });

    //批量删除
    $(".delAll_btn").click(function(){
        var checkStatus = table.checkStatus('newsListTable'),
            data = checkStatus.data,
            newsId = [];
        if(data.length > 0) {
            for (var i in data) {
                newsId.push(data[i].id);
            }
            layer.confirm('确定删除选中的组织？', {icon: 3, title: '提示信息'}, function (index) {
                $.ajax({
                    url:uploadurl+'/organization/deleteOrganization',
                    type:"post",
                    contentType:"application/json",
                    data:JSON.stringify({ids: newsId}),
                    traditional:true,
                    dataType: "json",
                    headers:{
                        token:token
                    },
                    success:function (msg) {
                        tableIns.reload();
                        layer.close(index);
                        layer.msg("删除成功！");
                    }
                });
            })
        }else{
            layer.msg("请选择需要删除的组织");
        }
    });

    //列表操作  删除 修改
    table.on('tool(newsList)', function(obj){
        var layEvent = obj.event,
            data = obj.data;
        if(layEvent === 'edit'){ //编辑
            editorg(data);
        } else if(layEvent === 'del'){ //删除
            layer.confirm('确定删除此组织？',{icon:3, title:'提示信息'},function(index){
                var idstr=new Array();
                idstr[0]=data.id;
                $.ajax({
                    url:uploadurl+'/organization/deleteOrganization',
                    type:"post",
                    contentType:"application/json",
                    data:JSON.stringify({ids: idstr}),
                    traditional:true,
                    dataType: "json",
                    headers:{
                        token:token
                    },
                    success:function (msg) {
                        tableIns.reload();
                        layer.close(index);
                        layer.msg("删除成功！");
                    }
                });
            });
        }
    });

    //修改
    function editorg(edit){
        var index = layui.layer.open({
            title : "组织修改",
            type : 2,
            content: '../../org/orgentry/orgEntry.html',
            area:['80%','95%'],
            success : function(layero, index){
                var body = layui.layer.getChildFrame('body', index);
                if(edit) {
                    body.find("#filediv").hide();
                    body.find("#submitorg")[0].innerText = "修改";
                    body.find("#name").val(edit.name);
                    body.find("#primeBusiness").val(edit.primeBusiness);
                    body.find("#legalPerson").val(edit.legalPerson);
                    body.find("#remark").val(edit.remark);
                    body.find("#getid").attr("name", edit.id);
                    body.find("#detail").val(edit.detail);

                    //typelevel
                    var clicknodetypelevel = body.find("[xid=typelevel]").children().children();
                    clickconditons(clicknodetypelevel, 1, edit.level, edit.type);

                    //provincecity
                    var clicknode = body.find("[xid=provincecity]").children().children();
                    clickoption(clicknode, 0, edit.country);
                    if (edit.province !== "") {
                        var jnum = clickoption(clicknode, 1, edit.province);
                    }
                    if (edit.city !== "") {
                        clickconditons(clicknode, 2, edit.city, clicknode.eq(1).children().eq(jnum)[0].attributes.value.value)
                    }

                    //我司入会？
                    if (edit.companyEngaged == 1) {
                        body.find("#companyEngaged").next().find("dl dd").eq(1).click();
                        body.find("#companyLevel").val(edit.companyLevel);
                        body.find("#companyTerm").val(edit.companyTerm);
                    } else {
                        body.find("#companyEngaged").next().find("dl dd").eq(2).click();
                    }

                    //我司人员入会？
                    if (edit.leaderEngaged == 1) {
                        body.find("#leaderEngaged").next().find("dl dd").eq(1).click();
                        body.find("#leaderName").val(edit.leaderName);
                        for (var i = 0; i < body.find("#leaderJob").next().find("dl dd").length; i++) {
                            if (edit.leaderJob == body.find("#leaderJob").next().find("dl dd").eq(i)[0].innerText) {
                                body.find("#leaderJob").next().find("dl dd").eq(i).click();
                            }
                        }
                        body.find("#leaderTerm").val(edit.leaderTerm);
                    } else {
                        body.find("#leaderEngaged").next().find("dl dd").eq(2).click();
                    }

                    // form.render();
                    function clickoption(clicknode, eq, edittext) {
                        var j = 0;
                        for (var i = 0; i < clicknode.eq(eq).children().length; i++) {
                            if (edittext == clicknode.eq(eq).children().eq(i)[0].innerText) {
                                clicknode.eq(eq).children().eq(i).click();
                                j = i;
                            }
                        }
                        return j;
                    }

                    function clickconditons(clicknode, eq, edittext, edittextpid) {
                        for (var i = 0; i < clicknode.eq(eq).children().length; i++) {
                            if (edittext == clicknode.eq(eq).children().eq(i)[0].innerText && edittextpid == clicknode.eq(eq).children().eq(i)[0].attributes.pid.value) {
                                clicknode.eq(eq).children().eq(i).click();
                            }
                        }
                    }
                }
            },
            cancel:function () {
                layer.closeAll();
            }
        })
    }

    $(".filedownload").on("click",function(){
        // var fileurl = new Array();
        // fileurl=uploadurl+'/organization/fileExport?token='+'123';
        // fileurl+="&companyEngaged="+$("#companyEngaged").val();
        // fileurl+="&leaderEngaged="+$("#leaderEngaged").val();
        // fileurl+="&name="+$("#name").val().replace(/(^\s*)|(\s*$)/g,"");
        // fileurl+="&type="+$("#type").val();
        // fileurl+="&submitterDepartment="+$("[name='submitterDepartment']").parent()[0].innerText;
        // fileurl+="&primeBusiness="+$("#primeBusiness").val();
        // window.location.href=fileurl;

            var xhr = new XMLHttpRequest();
            xhr.open('post',uploadurl+'/organization/fileExport',true);
            xhr.setRequestHeader('token','123');    //token认证
            xhr.setRequestHeader('content-type','application/json');
            xhr.responseType = 'blob';              //返回类型blob
            xhr.onload = function(){
                if(this.status == 200){
                    var blob = this.response;
                    var url = window.URL.createObjectURL(blob);
                    var a = document.createElement('a');
                    a.download = 'organization.xlsx';
                    a.href = url;
                    $('body').append(a);
                    a.click();
                    $(a).remove();
                }
            };
            //获取查询条件
            var parameter = {};
            parameter.companyEngaged = $('#companyEngaged').val();
            parameter.leaderEngaged = $('#leaderEngaged').val();
            parameter.name = $("#name").val().replace(/(^\s*)|(\s*$)/g,"");
            parameter.type = $('#type').val();
            parameter.submitterDepartment = $("[name='submitterDepartment']").parent()[0].innerText;
            parameter.primeBusiness = $('#primeBusiness').val();
            console.log(parseInt);
            xhr.send(JSON.stringify(parameter));
    });
});