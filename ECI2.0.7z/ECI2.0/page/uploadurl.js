var stateurl="http://172.17.0.11:8080/ECI2.0";
var uploadurl="http://172.17.0.1:8080";
var fileurl="http://172.17.0.1:8085";


// var uploadurl="http://172.17.0.6:8080";

var localurl="http://localhost:8080/ECI2.0";

//getsession
var usermess = JSON.parse(sessionStorage.getItem("usermess"));
var token = usermess.token;
var name = usermess.name;
var email = usermess.email;
function logout() {
    $.ajax({
        url:uploadurl+"/login/ssoLogout",
        type:"get",
        headers:{
          token:token
        },
        dataType: "json",
        success:function (msg) {
            window.location.href=localurl+"login.html";
        }
    });
}

function outtime(code) {
    if (code==15){
        window.location.href=localurl+"login.html";
    }
}
