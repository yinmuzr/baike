layui.use(['form','layer','laydate','table','laytpl','laypage'],function() {
    var form = layui.form,
        layer = parent.layer === undefined ? layui.layer : top.layer,
        $ = layui.jquery, layer = layui.layer,
        table = layui.table;

    //渲染列表
    var tableIns = table.render({
        elem: '#newsList',
        url: uploadurl + '/role/getListByPage',
        method: 'post',
        request: {
            limitName: 'size'
        },
        response: {
            countName: 'amount'
        },
        headers: {
            token: token
        },
        even: true,
        contentType: 'application/json',
        cellMinWidth: 95,
        page: true,
        height: 'full',
        id: 'newsListTable',
        cols: [[
            {type: 'numbers', title: '序号', width: 60, fixed:"left"},
            {field: 'name', title: '角色', width: 150},
            {field: 'baseAuthorDesc', title: '基本权限'},
            {field: 'description', title: '描述',width: 450},
            {title: '操作', width:140, templet:'#newsListBar',align:"center",fixed:'right'}
        ]]
    });

    //列表操作  删除 修改
    table.on('tool(newsList)', function(obj){
        var layEvent = obj.event,
            data = obj.data;
        if(layEvent === 'edit'){ //编辑
            edituser(data);
        } else if(layEvent === 'del'){ //删除
            layer.confirm('确定删除此角色？',{icon:3, title:'提示信息'},function(index){
                var idstr=new Array();
                idstr[0]=data.id;
                $.ajax({
                    url:uploadurl+'/role/delete',
                    type:"post",
                    contentType:"application/json",
                    data:JSON.stringify({ids: idstr}),
                    traditional:true,
                    dataType: "json",
                    headers:{
                        token:token
                    },
                    success:function (msg) {
                        tableIns.reload();
                        layer.close(index);
                        layer.msg("删除成功！");
                    }
                });
            });
        }
    });

    //修改
    function edituser(edit){
        var index = layui.layer.open({
            title : "组织修改",
            type : 2,
            content: '../../manange/role/roleadd.html',
            area:['500px','500px'],
            success : function(layero, index){
                var body = layui.layer.getChildFrame('body', index);
                if(edit){
                    body.find("#addLink").attr("name",edit.id);
                    body.find("#name").val(edit.name);
                    body.find("#description").val(edit.description);
                    for(var i = 2;i < body.find("[xid=baseAuthor]").children().length-2;i++){
                        if((edit.baseAuthor).indexOf(body.find("[xid=baseAuthor]").children().eq(i)[0].attributes[0].value)!=-1){
                           body.find("[xid=baseAuthor]").children().eq(i).click();
                        }
                    }
                    form.render();
                }
            },
            cancel:function () {
                layer.closeAll();
            }
        })
    }

});