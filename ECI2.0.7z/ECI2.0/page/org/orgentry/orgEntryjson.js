var level =
    [
                {
                    "value": "行业协会",
                    "name": "行业协会",
                    "children": [
                        {
                            "value": "一级",
                            "name": "一级"
                        },
                        {
                            "value": "二级",
                            "name": "二级"
                        },
                        {
                            "value": "三级",
                            "name": "三级"
                        },
                        {
                            "value": "其他",
                            "name": "其他"
                        },
                        {
                            "value": "无",
                            "name": "无"
                        }

                    ]
                },
        {
            "value": "政府",
            "name": "政府",
            "children": [
                {
                    "value": "国家级",
                    "name": "国家级"
                },
                {
                    "value": "省部级",
                    "name": "省部级"
                },
                {
                    "value": "市级",
                    "name": "市级"
                },
                {
                    "value": "区级",
                    "name": "区级"
                },
                {
                    "value": "其他",
                    "name": "其他"
                },
                {
                    "value": "无",
                    "name": "无"
                }


            ]
        },
    {
        "value": "高校",
        "name": "高校",
        "children": [
            {
                "value": "其他",
                "name": "其他"
            },
            {
                "value": "无",
                "name": "无"
            }
        ]
    },
        {
        "value": "企业",
        "name": "企业",
        "children": [
            {
                "value": "其他",
                "name": "其他"
            },
            {
                "value": "无",
                "name": "无"
            }
        ]
    },

        {
            "value": "科研院所",
            "name": "科研院所",
            "children": [
                {
                    "value": "其他",
                    "name": "其他"
                },
                {
                    "value": "无",
                    "name": "无"
                }
            ]
        },
        {
            "value": "事业单位",
            "name": "事业单位",
            "children": [
                {
                    "value": "国家直属",
                    "name": "国家直属"
                },
                {
                    "value": "省部直属",
                    "name": "省部直属"
                },
                {
                    "value": "其他",
                    "name": "其他"
                },
                {
                    "value": "无",
                    "name": "无"
                }
            ]
        },
        {
            "value": "其他",
            "name": "其他",
            "children": [
                {
                    "value": "其他",
                    "name": "其他"
                },
                {
                    "value": "无",
                    "name": "无"
                }
            ]
        }
    ];

