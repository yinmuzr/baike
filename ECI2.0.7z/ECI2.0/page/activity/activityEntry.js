//获取用户信息
var usermess = JSON.parse(sessionStorage.getItem('usermess'));
$('#submitterEmail').val(usermess.email);
$('#submitterDepartment').val(usermess.department);
$('#submitterOffice').val(usermess.office);

// 触发input[type=file]
var selectFile = {
    ms:function(){                                                        //触发会议纪要文件上传
        document.getElementById('meetingSummary1').click(); 
    },
    mn:function(){                                                        //触发会议通知文件上传
        document.getElementById('meetingNotice1').click(); 
    },
    mp:function(){                                                        //触发照片文件上传
        document.getElementById('meetingPicture1').click(); 
    },
    mpp:function(){                                                        //触发会议PPT文件上传
        document.getElementById('meetingPPT1').click(); 
    }
};

// 上传文件
var uploadFile = { 
    msFiles:[],mnFiles:[],mpFiles:[],mppFiles:[],                            //msFiles--会议纪要；mnFiles--会议通知；mpFiles--照片；mppFiles--会议PPT
    // 会议纪要
    meetingSummary:function(file,elemId){                                   
        var fileList = file.files;                                          //获取上传文件的文件对象
        var msFiles = this.msFiles; 
        if(this.checkFile(msFiles,fileList,elemId)){
            $.each(fileList,function(index,value){                          //将文件对象保存到msFiles属性中                     
                msFiles.push(value);                                                                                 
            });
            var $simInput = $(elemId);                                   //锁定模拟input框   
            if(/请上传文件/g.test($simInput.text())){                    //清除'请上传文件'                   
                $simInput.text("");
            }
            $simInput.find('span').remove();                        //清除上一次的span标签
            $.each(msFiles,function(index,value){
                var spanIndex = 'item-' + index;
                var iIndex = 'item-icon-' + index;
                var span = "<span id='"+spanIndex+"'class='multiple-select'><font>"+value.name+"</font><i id='"+iIndex+"'class='iconfont icon-close'></i></span>";
                $simInput.append(span);
                $('#meetingSummary1').attr('value',index+1);                               //统计会议纪要文件个数(防止表单校验失败)
                //撤销上传文件
                $simInput.find("span i[id="+iIndex+"]").bind('click',function(e){  
                    msFiles.splice(index,1);                                               //删除msFiles属性中的文件对象    
                    $simInput.find("span[id="+spanIndex+"]").remove();                      //删除html中的span
                    if($simInput.children().length==0){
                        $simInput.text("请上传文件(仅限word、pdf文件)");
                        $('#meetingSummary1').attr('value',0);
                    }
                    e.stopPropagation();                                                    //阻止事件冒泡
                });
            });
        }
    },
    // 会议通知
    meetingNotice:function(file,elemId){                                               
        var fileList = file.files;                                          //获取上传文件的文件对象
        var mnFiles = this.mnFiles; 
        if(this.checkFile(mnFiles,fileList,elemId)){
            $.each(fileList,function(index,value){                       //将文件对象保存到mnFiles属性中                     
                mnFiles.push(value);                                                                                 
            });
            var $simInput = $(elemId);                                 //锁定模拟input框 
            if(/请上传文件/g.test($simInput.text())){                  //清除'请上传文件'                   
                $simInput.text("");
            }
            $simInput.find('span').remove();                        //清除上一次的span标签
            $.each(mnFiles,function(index,value){
                var spanIndex = 'item-' + index;
                var iIndex = 'item-icon-' + index;
                var span = "<span id='"+spanIndex+"'class='multiple-select'><font>"+value.name+"</font><i id='"+iIndex+"'class='iconfont icon-close'></i></span>"
                $simInput.append(span);
                //撤销上传文件
                $simInput.find("span i[id="+iIndex+"]").bind('click',function(e){  
                    mnFiles.splice(index,1);                                               //删除mnFiles属性中的文件对象 
                    $simInput.find("span[id="+spanIndex+"]").remove();                      //删除html中的span
                    if($simInput.children().length==0){
                        $simInput.text("请上传文件(仅限word、pdf文件)");
                    }
                    e.stopPropagation();                                                    //阻止事件冒泡
                });
            });
        } 
    }, 
    // 会议PPT
    meetingPPT:function(file,elemId){                                              
        var fileList = file.files;                                          //获取上传文件的文件对象
        var mppFiles = this.mppFiles; 
        if(this.checkFile(mppFiles,fileList,elemId)){
            $.each(fileList,function(index,value){                       //将文件对象保存到mppFiles属性中                     
                mppFiles.push(value);                                                                                 
            });
            var $simInput = $(elemId);                                 //锁定模拟input框 
            if(/请上传文件/g.test($simInput.text())){                  //清除'请上传文件'                   
                $simInput.text("");
            }
            $simInput.find('span').remove();                        //清除上一次的span标签
            $.each(mppFiles,function(index,value){
                var spanIndex = 'item-' + index;
                var iIndex = 'item-icon-' + index;
                var span = "<span id='"+spanIndex+"'class='multiple-select'><font>"+value.name+"</font><i id='"+iIndex+"'class='iconfont icon-close'></i></span>"
                $simInput.append(span);
                //撤销上传文件
                $simInput.find("span i[id="+iIndex+"]").bind('click',function(e){  
                    mppFiles.splice(index,1);                                               //删除mppFiles属性中的文件对象    
                    $simInput.find("span[id="+spanIndex+"]").remove();                      //删除html中的span
                    if($simInput.children().length==0){
                        $simInput.text("请上传文件(仅限ppt文件)");
                    }
                    e.stopPropagation();                                                    //阻止事件冒泡
                });
            });
        }                                 
    },
    // 照片
    meetingPicture:function(file,elemId){
        var fileList = file.files;                                          //获取上传图片的文件对象
        var mpFiles = this.mpFiles; 
        if(this.checkFile(mpFiles,fileList,elemId)){
            $.each(fileList,function(index,value){                          //将文件对象保存到mpFiles属性中                     
                mpFiles.push(value);                                                                                 
            });           
            var $simInput = $(elemId);                                      //锁定模拟input框 
            if(/请上传照片/g.test($simInput.text())){                        //清除'请上传照片'                   
                $simInput.text("");
            }
            $simInput.find('div').remove();                                //清除上一次的span标签
            $.each(mpFiles,function(index,value){   
                var reader = new FileReader();
                reader.readAsDataURL(value);                                //读取图片的文件对象
                reader.onload = function(e){                  
                    var imgURL = reader.result;
                    var divIndex = 'item-' + index;
                    var iIndex = 'item-icon-' + index;
                    var div = "<div id='"+divIndex+"'class='multiple-select-picture'><img class='multiple-imgStyle' src='"+imgURL+"'></img><i id='"+iIndex+"'class='iconfont icon-close closeImg'></i></div>"
                    $simInput.append(div);
                    $simInput.find("div i[id="+iIndex+"]").css('display','inline');
                    //撤销上传照片
                    $simInput.find("div i[id="+iIndex+"]").bind('click',function(e){ 
                        mpFiles.splice(index,1);                                               //删除mpFiles属性中的文件对象  
                        $simInput.find("div[id="+divIndex+"]").remove();                      //删除html中的span
                        if($simInput.children().length==0){
                            $simInput.text("请上传照片(仅限jpg、png、bmp、jpeg图片)");
                        }
                        e.stopPropagation();                                                    //阻止事件冒泡
                    });
                    
                }
            });
        } 
    },
    // 检测文件
    checkFile:function(fileObj,fileList,elemId){
        // 检测文件类型
        switch(elemId){
            case '#meetingSummary': 
                var type = /doc|docx|pdf/g; var SIZE = 1;break;
            case '#meetingNotice':
                var type = /doc|docx|pdf/g; var SIZE = 1;break;                
            case '#meetingPPT':
                var type = /ppt|pptx/g; var SIZE = 5;break;            
            case '#meetingPicture':
                var type = /jpg|png|bmp|jpeg/g; var SIZE = 30;break;            
        };
        for(var i = 0; i<fileList.length; i++){
            var name2 = fileList[i].name;
            var typearr2 = name2.toLowerCase().split('.');
            if(typearr2[typearr2.length-1].search(type)==-1){
                layer.tips('不支持'+typearr2[typearr2.length-1]+'格式的文件！',elemId,{
                    tips:3,
                    time:2000
                });
                return false;
            }; 
        };
        // 检测文件的文件名
        var sumSize=0;
        for(var i=0; i<fileObj.length;i++){
            sumSize += fileObj[i].size;                                 //上次上传文件大小总和
        };
        for(var i=0; i<fileList.length;i++){
            sumSize += fileList[i].size;                                //所有上传文件大小总和
            for(var j=i+1;j<fileList.length;j++){                       //检测这次上传文件的文件名是否有相同的
                if(fileList[i].name == fileList[j].name){
                    layer.tips(fileList[i].name+'文件已存在！',elemId,{
                        tips:3,
                        time:2000
                    });
                    return false;
                }
            }
            for(var k=0;k<fileObj.length;k++){                          //检测这次上传文件的文件名与上次上传的是否有相同的
                if(fileList[i].name == fileObj[k].name){
                    layer.tips(fileList[i].name+'文件已存在！',elemId,{
                        tips:3,
                        time:2000
                    });
                    return false;
                }
            }
        };
        // 检测文件大小
        if(sumSize>SIZE*1024*1024){
            layer.tips("文件大小总和不能超过"+SIZE+"M",elemId,{
                tips:3,
                time:2000
            });
            return false;
        }
        // 检测文件数量
        else if(fileObj.length+fileList.length>10){
            layer.tips('文件总数不能超过10个',elemId,{
                tips:3,
                time:2000
            });
            return false;
        }
        return true;
    },
    saveToFormData:function(fd){ 
        fd.delete('msFiles');fd.delete('mnFiles');fd.delete('mpFiles');fd.delete('mppFiles');     
        $.each(this.msFiles,function(index,value){
            fd.append('msFiles',value);          
        });
        $.each(this.mnFiles,function(index,value){
            fd.append('mnFiles',value);
        });        
        $.each(this.mpFiles,function(index,value){
            fd.append('mpFiles',value);
        });        
        $.each(this.mppFiles,function(index,value){
            fd.append('mppFiles',value);
        });
    }
};

//初始化FormData对象
initFormData = function(fd){
    fd.append('submitterEmail','');fd.append('submitterDepartment','');fd.append('submitterOffice','');fd.append('communicationTheme','');
    fd.append('type','');fd.append('intention','');fd.append('detail','');fd.append('keyMsg','');
    fd.append('startDate','');fd.append('endDate','');fd.append('country','');fd.append('province','');fd.append('city','');
    fd.append('inCommunicationMans','');fd.append('outCommunicationMans','');fd.append('readables','');fd.append('msFiles',[]);fd.append('mnFiles',[]);
    fd.append('mppFiles',[]);fd.append('mpFiles',[]);
    fd.append('assign','');fd.append('auditStatus','');fd.append('code','');fd.append('flag','web');    //额外字段
    fd.append('isSubmit','');
};

// 保存不需要提前处理的数据
saveOtherData = function(field,fd){
    fd.delete('submitterEmail');
    fd.delete('submitterDepartment');
    fd.delete('submitterOffice');
    fd.delete('communicationTheme');
    fd.delete('type');
    fd.delete('intention');
    fd.delete('detail');
    fd.delete('keyMsg');
    fd.delete("startDate");
    fd.delete("endDate");
    fd.delete('isSubmit');
    fd.append('submitterEmail',field.submitterEmail);
    fd.append('submitterDepartment',field.submitterDepartment);
    fd.append('submitterOffice',field.submitterOffice);
    fd.append('communicationTheme',field.communicationTheme);
    fd.append('type',field.type);
    fd.append('intention',field.intention);
    fd.append('detail',field.detail);
    fd.append('keyMsg',field.keyMsg);
    var activityTime = $('#activityTime').val();
    var date = activityTime.split(' - '); 
    fd.append('startDate',date[0]);
    fd.append('endDate',date[1]);
};

layui.use(['form','laydate','layer','jquery','formSelects'],function(){
    var form = layui.form;
    var laydate = layui.laydate;
    var layer = layui.layer;
    var $ = layui.jquery;
    var formSelects = layui.formSelects;
    var formdata = new FormData();
    initFormData(formdata);
    form.render();
    //会议纪要自定义验证
    form.verify({
        meetingSummary:function(value,item){                                                    //有点小bug
            if($('#meetingSummary1').attr('value') <= 0){
                $('#meetingSummary').parent().css('border','1px solid red');
                return '必填项不能为空';
            }
            else{
                $('#meetingSummary').parent().css('border','1px solid #e6d6d6');                
            }
        }
    });

    //活动时间 
    var activityTime = laydate.render({                                                                        
        elem:'#activityTime',
        range:true
    });

    //籍贯--加载本地数据    
    formSelects.data('communicatePlace','local',{                                           
        arr:Place,
        linkage:true,
    });
    formSelects.on('communicatePlace',function(id,vals,val,isAdd,isDisabled){
        if(isAdd){
            var name = val.name.split('/');
            formdata.delete("country");
            formdata.delete("province");
            formdata.delete("city");
            if(name[0]=='中国'){
                formdata.append("country",name[0]);
                formdata.append("province",name[1]);
                formdata.append("city",name[2]);
            }
            else{
                formdata.append("country",name[0]);
                formdata.append("province",'');
                formdata.append("city",'');
            }
        }else{
            formdata.delete("country");
            formdata.delete("province");
            formdata.delete("city");
        }
    });

    //公司交流人员
    formSelects.config('inCommunicationMans',{
        type:"post",
        header:{                                                                                  //认证信息
            token:usermess.token
        },                                                    
        searchUrl:baseURL_lbq + '/contacts/queryPerson',
        searchName:'name',
        searchVal:'',                                                                              //搜索内容在搜索一次后失效
        delay:500,                                                                                //搜索延迟时间500ms
        direction:'down',
        clearInput:true,
        beforeSearch: function(id,url,searchVal){
            if(!/^[\u4E00-\u9FA5]{2,}$/g.test(searchVal)){                                       //两位中文以上触发
                return false;
            }
            return true;
        },
        beforeSuccess:function(id,url,searchVal,result){
            var data = result.data;
            var arr = [];
            var res = {
                code:result.code,
                msg:result.msg,
            };
            for(var i=0; i<data.length; i++){
                arr[i] = {
                    name:data[i],
                    value:data[i]
                }
            }
            res.data = arr;
            return res;
        },
        success:function(id,url,searchVal,result){
            if(result.code == 0){
                // console.log(result);
            }
            else{             
                layer.tips('未知错误!','#icmTips',{
                    tips:2,
                    time:2000
                });
            }
        }
    });
    formSelects.on('inCommunicationMans',function(id,vals,val,isAdd,isDisabled){                     //监听公司交流人员选值
        var inCommunicationMans='';
        $.each(vals,function(index,value){
            inCommunicationMans += value.name+';';
        });
        if(isAdd){
            inCommunicationMans += val.name+';';
        }
        else{
            inCommunicationMans=inCommunicationMans.replace(val.name+';','');
        }
        formdata.delete('inCommunicationMans');
        formdata.append('inCommunicationMans',inCommunicationMans);
    });

    //外部交流人员
    formSelects.config('outCommunicationMans',{  
        type:"post",
        header:{                                                                                //认证信息
            token:usermess.token
        },                                                   
        searchUrl:baseURL_lbq + '/expert/queryExpert',
        searchName:'name',
        searchVal:'',                                                                           //搜索内容在搜索一次后失效
        delay:500,                                                                              //搜索延迟时间500ms
        direction:'down',
        clearInput:true,
        beforeSearch: function(id,url,searchVal){
            if(searchVal.length<2){
                return false;
            }
            return true;
        },
        beforeSuccess:function(id,url,searchVal,result){
            var data = result.data;
            var arr = [];
            var res = {
                code:result.code,
                msg:result.msg,
            };
            for(var i=0; i<data.length; i++){
                arr[i] = {
                    name:data[i],
                    value:data[i]
                }
            }
            res.data = arr;
            return res;
        },
        success:function(id,url,searchVal,result){
            if(result.code == 0){
            }
            else{      
                layer.tips('未知错误!','#ocmTips',{
                    tips:2,
                    time:2000
                });
            }
        }
    });
    formSelects.on('outCommunicationMans',function(id,vals,val,isAdd,isDisabled){                     //监听外部交流人员选值
        var outCommunicationMans='';
        $.each(vals,function(index,value){
            outCommunicationMans += value.name+';';
        });
        if(isAdd){
            outCommunicationMans += val.name+';';
        }
        else{
            outCommunicationMans=outCommunicationMans.replace(val.name+';','');
        }
        formdata.delete('outCommunicationMans');
        formdata.append('outCommunicationMans',outCommunicationMans);
    });

    //指定
    formSelects.config('readables',{                                                   
        type:"post",
        header:{                                                                                 
            token:usermess.token
        },                                                    
        searchUrl:baseURL_lbq + '/contacts/queryPerson',
        searchName:'name',
        searchVal:'',                                                                           
        delay:500,                                                                              
        direction:'down',
        clearInput:true,
        beforeSearch: function(id,url,searchVal){
            if(!/^[\u4E00-\u9FA5]{2,}$/g.test(searchVal)){                                        
                return false;
            }
            return true;
        },
        beforeSuccess:function(id,url,searchVal,result){
            var data = result.data;
            var arr = [];
            var res = {
                code:result.code,
                msg:result.msg,
            };
            for(var i=0; i<data.length; i++){
                arr[i] = {
                    name:data[i],
                    value:data[i]
                }
            }
            res.data = arr;
            return res;
        },
        success:function(id,url,searchVal,result){
            if(result.code == 0){
                // console.log(result);
            }
            else{
                // console.log(result);                
                layer.tips('未知错误!','#readsTips',{
                    tips:2,
                    time:2000
                });
            }
        }
    });
    formSelects.on('readables',function(id,vals,val,isAdd,isDisabled){                     //监听指定选值
        var readables='';
        $.each(vals,function(index,value){
            readables += value.name+';';
        });
        if(isAdd){
            readables += val.name+';';
        }
        else{
            readables=readables.replace(val.name+';','');
        }
        formdata.delete('readables');
        formdata.append('readables',readables);
    });

    //监听提交
    form.on('submit(submitActivity)',function(data){
        uploadFile.saveToFormData(formdata);                                                 //将附件存入FormData对象中 
        saveOtherData(data.field,formdata);                                                 //将不需要处理的其它数据存入formdata对象中
        formdata.append('isSubmit',1);                                                     
        var loadIndex = layer.load(1,{
            shade:[0.6,'#000']
        });
        if(data.field.id == ''){
            $.ajax({
                url: baseURL_lbq + '/activity/addActivity',
                type:'POST',
                headers:{
                    token:usermess.token
                },
                data:formdata,
                cache:false,
                processData:false,                                                            //jquery不去处理发送的数据
                contentType:false,                                                            //jquery不设置Content-Type请求头
                success:function(res){
                    if(res.code == 0){
                        layer.close(loadIndex);
                        layer.msg('上传成功！',{time:1500});                    
                        location.href = './activityEntry.html';                              //上传成功后,刷新页面                                         
                    }
                    else{        
                        layer.msg('上传失败！',{time:2000});
                        layer.close(loadIndex);                         
                    }
                }
            })
        }
        else{
            formdata.append('id',data.field.id);
            // formdata.append('auditStatus',data.field.auditStatus);
            var arr = $('#deleteFiles').attr('value').split(';');
            for(var i=0;i<arr.length-1;i++){
                formdata.append('deleteFiles',parseInt(arr[i]));
            }
            $.ajax({
                url: baseURL_lbq + '/activity/updateActivity',
                type:'POST',
                headers:{
                    token:usermess.token
                },
                data:formdata,
                cache:false,
                processData:false,                                                            //jquery不去处理发送的数据
                contentType:false,                                                            //jquery不设置Content-Type请求头
                success:function(res){
                    if(res.code == 0){
                        layer.close(loadIndex);
                        layer.msg('修改成功！',{time:1500}); 
                        setTimeout(function(){
                            IFrame.close();     
                            if(data.field.auditStatus==2){
                                parent.layui.table.reload('activityTable');                      //查询--修改成功后,刷新页面
                            }
                            else if(data.field.auditStatus==1){
                                parent.layui.table.reload('waitComplete',{                          //待完善--修改成功后,刷新页面
                                    url:baseURL_lbq + '/activity/getActivitiesByParams',
                                    where:{
                                      auditStatus: 1
                                    },
                                    cols: [[ //表头                             
                                      {type:'checkbox',fixed:'left'},
                                      {title: '<span style="color:#000;font-weight:bold;">序号</span>',minWidth:100,templet:function(d){ 
                                        return d.LAY_INDEX;
                                      }},
                                      {field: 'createTime', title: '<span style="color:#000;font-weight:bold;">录入日期</span>',},
                                      {field: 'communicationTheme', title: '<span style="color:#000;font-weight:bold;">交流主题</span>'},
                                      {field: 'assign', title: '<span style="color:#000;font-weight:bold;">指派人</span>'},
                                      {field: '',title:'<span style="color:#000;font-weight:bold;">操作</span>',minWidth:170,toolbar:'#waitEventBar',fixed:'right'}           //toolbar-绑定工具条
                                    ]],
                                }); 
                            }                                                                                                                              
                            else if(data.field.auditStatus==0){
                                parent.layui.table.reload('waitReview',{                            //待审核--修改成功后,刷新页面 
                                    url:baseURL_lbq + '/activity/getActivitiesByParams',
                                    where:{
                                        auditStatus: 0,
                                    },
                                    cols: [[ //表头                             
                                        {type:'checkbox',fixed:'left'},
                                        {title: '<span style="color:#000;font-weight:bold;">序号</span>',width:80,templet:function(d){ 
                                          return d.LAY_INDEX;
                                        }},
                                        {field: 'createTime', title: '<span style="color:#000;font-weight:bold;">录入日期</span>',},
                                        {field: 'communicationTheme', title: '<span style="color:#000;font-weight:bold;">交流主题</span>'},
                                        {field: '',title:'<span style="color:#000;font-weight:bold;">详情</span>',width:150,toolbar:'#detail',},         
                                        {field: 'rejectReason',title:'<span style="color:#000;font-weight:bold;">驳回原因</span>',edit:'text'},                                                 
                                        {field: '',title:'<span style="color:#000;font-weight:bold;">操作</span>',toolbar:'#waitEventBar',},                   
                                    ]]
                                }); 
                            }                                                                                                                                                       
                            else if(data.field.auditStatus==3){
                                parent.layui.table.reload('rejected',{                            //被驳回--修改成功后,刷新页面 
                                    url:baseURL_zcw + '/activity/getActivitiesByParams',
                                    where:{
                                      auditStatus: 3,
                                    },
                                    cols: [[ //表头                             
                                      {type:'checkbox',fixed:'left'},
                                      {title: '<span style="color:#000;font-weight:bold;">序号</span>',minWidth:100,templet:function(d){ 
                                        return d.LAY_INDEX;
                                      }},
                                      {field: 'createTime', title: '<span style="color:#000;font-weight:bold;">录入日期</span>',},
                                      {field: 'communicationTheme', title: '<span style="color:#000;font-weight:bold;">交流主题</span>'},
                                      {field: 'rejectReason', title: '<span style="color:#000;font-weight:bold;">驳回原因</span>'},
                                      {field: '',title:'<span style="color:#000;font-weight:bold;">操作</span>',minWidth:170,toolbar:'#waitEventBar',fixed:'right'}           //toolbar-绑定工具条
                                    ]]
                                });  
                            }                                                                                                                                                                          
                        },1000);
                    }
                    else{        
                        layer.close(loadIndex);                        
                        layer.msg('修改失败！',{time:1500});
                        setTimeout(function(){
                            IFrame.close();                                                                                                           
                        },1500);                                         
                    }
                }
            })
        }
        return false;
    });

    //监听保存
    form.on('submit(saveActivity)',function(data){
        uploadFile.saveToFormData(formdata);                                                 
        saveOtherData(data.field,formdata);   
        formdata.append('isSubmit',0);                                             
        var loadIndex = layer.load(1,{
            shade:[0.6,'#000']
        });
        $.ajax({
            url: baseURL_lbq + '/activity/addActivity',
            type:'POST',
            headers:{
                token:usermess.token
            },
            data:formdata,
            cache:false,
            processData:false,                                                            //jquery不去处理发送的数据
            contentType:false,                                                            //jquery不设置Content-Type请求头
            success:function(res){
                if(res.code == 0){
                    layer.close(loadIndex);
                    layer.msg('保存成功！',{time:1500});                    
                    location.href = './activityEntry.html';                              //上传成功后,刷新页面                                         
                }
                else{        
                    layer.msg('保存失败！',{time:2000});
                    layer.close(loadIndex);                         
                }
            }
        });
        return false;
    });
});

