//获取用户信息
var usermess = JSON.parse(sessionStorage.getItem('usermess'));
$('#submitterEmail').val(usermess.email);
$('#submitterDepartment').val(usermess.department);
$('#submitterOffice').val(usermess.office);
var uploadImg = {
    preview : function(file,imgId){                                        //图片预览
        var img = document.getElementById(imgId);
        if(file.files && file.files[0]){
            // 校验上传的文件是否为图片格式                
            if(!/image\/\w+/.test(file.files[0].type)){
                layer.tips('文件必须为图片格式','#previewImg',{
                    tips:3,
                    time:1000
                });
            }
            // 限制上传照片最大为2M,然后预览
            else{
                var reader = new FileReader();
                reader.readAsDataURL(file.files[0]);
                // 读取过程中
                reader.onprogress = function(e){

                }
                // 读取失败
                reader.onerror = function(){                                        
                    return '图片上传失败';
                }
                // 读取完成
                reader.onload = function(e){
                    if(file.files[0].size>2*1024*1024){
                        layer.tips('图片必须小于2M','#previewImg',{
                            tips:3,
                            time:1000
                        })
                    }else{
                        var imgSrc = reader.result;
                        img.src = imgSrc;
                        var i = "<i id='closeImg' class='iconfont icon-close closeImg'></i>"                //删除照片功能
                        $('#previewImg').parent().append(i);
                        $('#previewImg').siblings().bind('click',function(e){
                            var file = document.getElementById('personImg');
                            img.src = '../../images/add.png';
                            $('#previewImg').parent().find('i').remove();
                            file.value = '';
                            e.stopPropagation();
                        });
                    }
                } 
            }
        }
        else{
            img.src = file.value;
        }
    },

    saveToFormData : function(fd){                                      //将图片存入FormData中
        var file = document.getElementById('personImg');
        var picture = file.files[0];
        fd.delete('picture');  
        if(picture != undefined){
            fd.append('picture',picture);
        }         
    }
};

//初始化FormData对象
initFormData = function(fd){
    fd.append('country','');fd.append('province','');fd.append('city','');fd.append('engagedTerm','');
    fd.append('primeCompanyId','');fd.append('secondCompanyIds','');fd.append('readables','');fd.append('engaged','');
    // fd.append('picture','');

    fd.append('submitterEmail','');fd.append('submitterDepartment','');fd.append('submitterOffice','');fd.append('name','');
    fd.append('researchDirection','');fd.append('department','');fd.append('job','');fd.append('jobTitle','');
    fd.append('gender','');fd.append('birthday','');fd.append('mobileNumber','');fd.append('email','');
    fd.append('phoneNumber','');fd.append('engagedDepartment','');fd.append('otherJob','');fd.append('remark','');

    fd.append('flag','web');     //额外字段
};

// 保存不需要提前处理的数据
saveOtherData = function(field,fd){
    fd.delete('submitterEmail');fd.delete('submitterDepartment');fd.delete('submitterOffice');fd.delete('name');
    fd.delete('researchDirection');fd.delete('department');fd.delete('job');fd.delete('jobTitle');
    fd.delete('gender');fd.delete('mobileNumber');fd.delete('email');fd.delete('engagedTerm');
    fd.delete('phoneNumber');fd.delete('engagedDepartment');fd.delete('otherJob');fd.delete('remark');

    fd.append('submitterEmail',field.submitterEmail);
    fd.append('submitterDepartment',field.submitterDepartment);
    fd.append('submitterOffice',field.submitterOffice);
    fd.append('name',field.name);
    fd.append('researchDirection',field.researchDirection);
    fd.append('department',field.department);
    fd.append('job',field.job);
    fd.append('jobTitle',field.jobTitle);
    fd.append('gender',field.gender);
    fd.append('mobileNumber',field.mobileNumber);
    fd.append('email',field.email);
    fd.append('phoneNumber',field.phoneNumber);
    fd.append('engagedDepartment',field.engagedDepartment);
    fd.append('otherJob',field.otherJob);
    fd.append('remark',field.remark);
    fd.append('engagedTerm',$('#engagedTerm').val());
};


layui.use(['form','laydate','jquery','formSelects'],function(){
    var form = layui.form;
    var laydate = layui.laydate;
    var $ = layui.jquery;
    var formSelects = layui.formSelects;
    var formdata = new FormData();
    initFormData(formdata);

    //自定义表单验证
    form.verify({
        mobileNumber:function(value){
            var patternMobile = /^1[3584]\d{9}$/g;
            if(!patternMobile.test(value)){
                return '请输入正确手机号';
            }
        },
        email:function(value){
            var patternEmail = /@/g;
            if(value.length == 0){
            }else{
                if(value.search(patternEmail) == -1){
                    return '请输入正确邮箱号';
                }
            }
        },
        phoneNumber:function(value){
            var patternPhone = /^0\d{2,3}-\d{7,8}$/g;
            if(value.length == 0){
            }else{
                if(!patternPhone.test(value)){
                    return '请输入正确电话号码';
                }
            }
        },
    })
    //生日
    formSelects.data('birthday','local',{                                                  
        arr:MonthDay,
        linkage:true,
    }); 
    formSelects.on('birthday',function(id,vals,val,isAdd,isDisabled){   
        if(isAdd){
            var name = val.name.split('/');
            var birthday1 = name[0]+'-'+name[1];
            formdata.delete('birthday');
            formdata.append('birthday',birthday1);       
        } 
    });   
    
    //聘期
    var engagedTerm = laydate.render({                                                               
        elem:'#engagedTerm',
        range:true
    });
    
    //籍贯--加载本地数据
    formSelects.data('birthPlace','local',{                                                  
        arr:Place,
        linkage:true,
    }); 
    formSelects.on('birthPlace',function(id,vals,val,isAdd,isDisabled){
        if(isAdd){
            var name = val.name.split('/');
            formdata.delete("country");
            formdata.delete("province");
            formdata.delete("city");
            if(name[0]=='中国'){
                formdata.append("country",name[0]);
                formdata.append("province",name[1]);
                formdata.append("city",name[2]);
            }
            else if(name[0]=='其他国家'){
                formdata.append("country",name[0]);
                formdata.append("province",'');
                formdata.append("city",'');
            }
        }else{
            formdata.delete("country");
            formdata.delete("province");
            formdata.delete("city");
        }
    });

    //主属单位
    formSelects.config('primeCompanyId',{
        type:"post",
        header:{                                                                                  //认证信息
            token:usermess.token
        },                                                    
        searchUrl:baseURL_zcw + '/organization/getOrgListByOrgName',
        searchName:'orgName',
        searchVal:'',                                                                              //搜索内容在搜索一次后失效
        delay:500,                                                                                //搜索延迟时间500ms
        direction:'down',
        clearInput:true,
        beforeSearch: function(id,url,searchVal){
            if(searchVal.length<2){
                return false;
            }
            return true;
        },
        beforeSuccess:function(id,url,searchVal,result){
            var data = result.data;
            var arr = [];
            var res = {
                code:result.code,
                msg:result.msg,
            };
            if(data.length == 0){
                arr[0]= {
                    name:'No resaults for 组织 ?去创建主属单位',
                    value:'noResults'
                }
            }else{
                for(var i=0; i<data.length; i++){
                    arr[i] = {
                        name:data[i],
                        value:data[i]
                    }
                }
            }
            res.data = arr;
            return res;
        },
        success:function(id,url,searchVal,result){
            var data = result.data;
            if(result.code == 0){
                $('#pcTips').find('span[name="No resaults for 组织 ?去创建主属单位"]').prev().remove();
            }
            else{             
                layer.tips('未知错误!','#pcTips',{
                    tips:2,
                    time:2000
                });
            }
        }
    });
    formSelects.on('primeCompanyId',function(id,vals,val,isAdd,isDisabled){                     //监听主属单位选值
        if(val.val=='noResults' && isAdd){
            IFrame.open('../org/orgentry/orgEntry.html',val);
            return false;
        }else{
            var primeCompanyId='';
            if(isAdd){
                primeCompanyId = val.name;
            }
            else{
                primeCompanyId=primeCompanyId.replace(val.name,'');
            }
            formdata.delete('primeCompanyId');
            formdata.append('primeCompanyId',primeCompanyId);
        }
    });

    //从属单位
    formSelects.config('secondCompanyIds',{
        type:"post",
        header:{                                                                              
            token:usermess.token
        },                                                    
        searchUrl:baseURL_zcw + '/organization/getOrgListByOrgName',
        searchName:'orgName',
        searchVal:'',                                                                             
        delay:500,                                                                                
        direction:'down',
        clearInput:true,
        beforeSearch: function(id,url,searchVal){
            if(searchVal.length<2){
                return false;
            }
            return true;
        },
        beforeSuccess:function(id,url,searchVal,result){
            var data = result.data;
            var arr = [];
            var res = {
                code:result.code,
                msg:result.msg,
            };
            for(var i=0; i<data.length; i++){
                arr[i] = {
                    name:data[i],
                    value:data[i]
                }
            }
            res.data = arr;
            return res;
        },
        success:function(id,url,searchVal,result){
            if(result.code == 0){
                // console.log(result);
            }
            else{             
                layer.tips('未知错误!','#scTips',{
                    tips:2,
                    time:2000
                });
            }
        }
    });
    formSelects.on('secondCompanyIds',function(id,vals,val,isAdd,isDisabled){                     //监听从属单位选值
        var secondCompanyIds='';
        $.each(vals,function(index,value){
            secondCompanyIds += value.name+';';
        });
        if(isAdd){
            secondCompanyIds += val.name+';';
        }
        else{
            secondCompanyIds=secondCompanyIds.replace(val.name+';','');
        }
        formdata.delete('secondCompanyIds');
        formdata.append('secondCompanyIds',secondCompanyIds);
    });

    //指定
    formSelects.config('readables',{
        type:"post",
        header:{                                                                                  
            token:usermess.token
        },                                                    
        searchUrl:baseURL_zcw + '/contacts/queryPerson',
        searchName:'name',
        searchVal:'',                                                                         
        delay:500,                                                                                
        direction:'down',
        clearInput:true,
        beforeSearch: function(id,url,searchVal){
            if(!/^[\u4E00-\u9FA5]{2,}$/g.test(searchVal)){                               //两位中文以上触发
                return false;
            }
            return true;
        },
        beforeSuccess:function(id,url,searchVal,result){
            var data = result.data;
            var arr = [];
            var res = {
                code:result.code,
                msg:result.msg,
            };
            for(var i=0; i<data.length; i++){
                arr[i] = {
                    name:data[i],
                    value:data[i]
                }
            }
            res.data = arr;
            return res;
        },
        success:function(id,url,searchVal,result){
            if(result.code == 0){
                // console.log(result);
            }
            else{             
                layer.tips('未知错误!','#rdTips',{
                    tips:2,
                    time:2000
                });
            }
        }
    });
    formSelects.on('readables',function(id,vals,val,isAdd,isDisabled){                     //监听指定选值
        var readables='';
        $.each(vals,function(index,value){
            readables += value.name+';';
        });
        if(isAdd){
            readables += val.name+';';
        }
        else{
            readables=readables.replace(val.name+';','');
        }
        formdata.delete('readables');
        formdata.append('readables',readables);
    });

    // 监听人员检索
    $('#checkPerson').click(function(){
        var name = $('#name').val();
        var primeCompanyId = formdata.get('primeCompanyId');
        if(name == '' || primeCompanyId == ''){
            layer.tips('姓名和主属单位均不能为空','#checkPerson',{
                tips:3,
                time:2000
            });
        }
        else{
            $.ajax({
                url:baseURL_zcw + '/expert/checkExpert',
                type:'POST',
                dataType:"json",
                headers:{
                    token:usermess.token
                },
                data:{
                    name:name,
                    primeCompany:primeCompanyId
                },
                cache:false,
                success:function(res){
                    if(res.code == 0){
                        layer.msg(res.data,{time:2000});                                                         
                    }
                    else{        
                        layer.msg(res.data,{time:2000});
                    }
                }
            })
        }
        return false;
    })

    //监听是否为我司聘任专家
    form.on('select(engaged)',function(data){
        var value = data.value;
        if(value == '是'){
            $('#engagedDepartment').prop('disabled',false);
            $('#engagedTerm').prop('disabled',false);
            $('#engagedDepartment').attr('lay-verify','required');
            $('#engagedTerm').attr('lay-verify','required');
            $('#redStar1').attr('class','layui-red');
            $('#redStar2').attr('class','layui-red');
        }
        else if(value == '否'  || value == ''){
            $('#engagedDepartment').prop('disabled',true);
            $('#engagedTerm').prop('disabled',true);
            $('#engagedDepartment').attr('lay-verify','');
            $('#engagedTerm').attr('lay-verify','');
            $('#redStar1').attr('class','layui-red redStar');
            $('#redStar2').attr('class','layui-red redStar');
        }
        formdata.delete('engaged');
        formdata.append('engaged',value);
    });
    
    //表单提交
    form.on('submit(submitPerson)',function(data){
        var field = data.field;
        uploadImg.saveToFormData(formdata);
        saveOtherData(field,formdata);                    
        var loadIndex = layer.load(1,{
            shade:[0.6,'#000']
        });
        if(field.id == ''){
            $.ajax({
                url: baseURL_zcw + '/expert/add',
                type:'POST',
                headers:{
                    token:usermess.token
                },
                data:formdata,
                cache:false,
                processData:false,                                                            //jquery不去处理发送的数据
                contentType:false,                                                            //jquery不设置Content-Type请求头
                success:function(res){
                    if(res.code == 0){
                        layer.close(loadIndex);
                        layer.msg('上传成功！',{time:1500});                  
                        location.href = './personEntry.html';                                //上传成功后,刷新页面                                         
                    }
                    else if(res.code == 8){  
                        layer.msg('权限不足,请确认您的权限范围',{time:1500});
                        layer.close(loadIndex);                                                 
                    }
                    else{       
                        layer.msg('上传失败！',{time:1500});
                        layer.close(loadIndex); 
                    }
                }
            })
        }
        else{
            formdata.append('id',field.id);
            // formdata.append('auditStatus',data.field.auditStatus);
            $.ajax({
                url: baseURL_zcw + '/expert/modify',
                type:'POST',
                headers:{
                    token:usermess.token
                },
                data:formdata,
                cache:false,
                processData:false,                                                            //jquery不去处理发送的数据
                contentType:false,                                                            //jquery不设置Content-Type请求头
                success:function(res){
                    if(res.code == 0){
                        layer.close(loadIndex);
                        layer.msg('修改成功！',{time:1500});
                        setTimeout(function(){
                            IFrame.close();  
                            if(data.field.auditStatus==2){
                                parent.layui.table.reload('personTable');                          //查询--修改成功后,刷新页面                                                                                                                                                                               
                            }  
                            else if(data.field.auditStatus==1){
                                parent.layui.table.reload('waitComplete',{                         //待完善--修改成功后,刷新页面  
                                    url:baseURL_zcw + '/expert/getList',
                                    where:{
                                      flag: "WAIT_COMPLETE",
                                    },
                                    cols: [[ //表头                             
                                      {type:'checkbox',fixed:'left'},
                                      {title: '<span style="color:#000;font-weight:bold;">序号</span>',minWidth:100,fixed:'left',templet:function(d){ 
                                        return d.LAY_INDEX;
                                      }},
                                      {field: 'createTime', title: '<span style="color:#000;font-weight:bold;">录入日期</span>',},
                                      {field: 'name', title: '<span style="color:#000;font-weight:bold;">姓名</span>'},
                                      {field: 'assign', title: '<span style="color:#000;font-weight:bold;">指派人</span>'},
                                      {field: '',title:'<span style="color:#000;font-weight:bold;">操作</span>',minWidth:170,toolbar:'#waitEventBar',fixed:'right'}           //toolbar-绑定工具条
                                    ]],
                                }); 
                            }                              
                            else if(data.field.auditStatus==0){
                                parent.layui.table.reload('waitReview',{                            //待审核--修改成功后,刷新页面 
                                    url:baseURL_zcw + '/expert/getList',
                                    where:{
                                        flag: "WAIT_AUDIT",
                                    },
                                    cols: [[ //表头                             
                                        {type:'checkbox',fixed:'left'},
                                        {title: '<span style="color:#000;font-weight:bold;">序号</span>',width:80,templet:function(d){ 
                                          return d.LAY_INDEX;
                                        }},
                                        {field: 'createTime', title: '<span style="color:#000;font-weight:bold;">录入日期</span>',},
                                        {field: 'name', title: '<span style="color:#000;font-weight:bold;">姓名</span>'},
                                        {field: '',title:'<span style="color:#000;font-weight:bold;">详情</span>',width:150,toolbar:'#detail',},
                                        {field: 'rejectReason',title:'<span style="color:#000;font-weight:bold;">驳回原因</span>',edit:'text'},                             
                                        {field: '',title:'<span style="color:#000;font-weight:bold;">操作</span>',toolbar:'#waitEventBar',},                   
                                      ]]
                                }); 
                            }  
                            if(data.field.auditStatus==3){
                                parent.layui.table.reload('rejected',{                            //被驳回--修改成功后,刷新页面 
                                    url:baseURL_zcw + '/expert/getList',
                                    where:{
                                      flag: "REJECTED"
                                    },
                                    cols: [[ //表头                             
                                      {type:'checkbox',fixed:'left'},
                                      {title: '<span style="color:#000;font-weight:bold;">序号</span>',minWidth:100,templet:function(d){ 
                                        return d.LAY_INDEX;
                                      }},
                                      {field: 'createTime', title: '<span style="color:#000;font-weight:bold;">录入日期</span>',},
                                      {field: 'name', title: '<span style="color:#000;font-weight:bold;">姓名</span>'},
                                      {field: 'rejectReason', title: '<span style="color:#000;font-weight:bold;">驳回原因</span>'},
                                      {field: '',title:'<span style="color:#000;font-weight:bold;">操作</span>',minWidth:170,toolbar:'#waitEventBar',fixed:'right'}           //toolbar-绑定工具条
                                    ]]
                                });    
                            }                                                                                                                                                                                                
                        },1500);                  
                    }
                    else if(res.code == 8){  
                        layer.close(loadIndex);                         
                        layer.msg('权限不足,请确认您的权限范围',{time:1500});
                        setTimeout(function(){
                            IFrame.close();    
                        },1500);
                    }
                    else{   
                        layer.close(loadIndex);                             
                        layer.msg('修改失败！',{time:1500});
                        setTimeout(function(){
                            IFrame.close();    
                        },1500);
                    }
                }
            })
        }
        return false;
    })
});


