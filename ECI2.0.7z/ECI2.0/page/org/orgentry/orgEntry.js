layui.use(['form', 'layer'], function () {
    var form = layui.form;
    $ = layui.jquery
        , layer = layui.layer;

//检索组织是否存在
    $("#orgSearch").on("click", function () {
        checkorgname();
    });

    function checkorgname() {
        var namestr = new Object();
        namestr.name = $("#name").val();
        var index = top.layer.msg('检索中，请稍候', {icon: 16, time: false, shade: 0.8});
        $.ajax({
            url: uploadurl + "/organization/checkOrganizationName",
            type: "post",
            contentType: "application/json",
            data: JSON.stringify(namestr),
            dataType: "json",
            headers: {
                token: token
            },
            success: function (msg) {
                top.layer.close(index);
                layer.open({
                    content: msg.data,
                    btn: ['确定'],
                    yes: function () {
                        layer.closeAll();
                    }
                })
            }
        });
        return false;
    }

    //监听提交
    form.on("submit(submitorg)", function (data) {
        data.field.provincecity = $("[name='provincecity']").parent()[0].innerText;
        data.field.type = data.field.typelevel.split("/")[0];
        data.field.level = data.field.typelevel.split("/")[1];
        data.field.flag = "web";
        data.field.country = data.field.provincecity.split("/")[0];

        if (data.field.provincecity.split("/")[1] != undefined) {
            data.field.province = data.field.provincecity.split("/")[1];
        }else {
            data.field.province="";
        }
        if (data.field.provincecity.split("/")[2] != undefined) {
            data.field.city = data.field.provincecity.split("/")[2];
        }else {
            data.field.city="";
        }

        delete(data.field["typelevel"]);
        delete(data.field["provincecity"]);

        console.log(data.field);
        var index = top.layer.msg('数据提交中，请稍候', {icon: 16, time: false, shade: 0.8});
        if ($("#submitorg")[0].innerText == "提交信息") {
            $.ajax({
                url: uploadurl + "/organization/addOrganization",
                type: "post",
                contentType: "application/json",
                data: JSON.stringify(data.field),
                dataType: "json",
                headers: {
                    token: token
                },
                success: function (msg) {
                    top.layer.close(index);
                    if (msg.code == 0) {
                        layer.open({
                            content: '提交成功',
                            btn: ['确定'],
                            yes: function (index, layero) {
                                layer.closeAll();
                                location.reload();
                            }
                        })
                    } else {
                        layer.msg(msg.msg);
                    }

                }
            });
        }
        else {
            data.field.id = $("#getid")[0].attributes[2].value;
            $.ajax({
                url: uploadurl + "/organization/updateOrganization",
                type: "post",
                contentType: "application/json",
                data: JSON.stringify(data.field),
                dataType: "json",
                headers: {
                    token: token
                },
                success: function (msg) {
                    top.layer.close(index);
                    if (msg.code == 0) {
                        layer.closeAll();
                        if ($("#submitorg")[0].innerText == "修改"){
                            parent.location.reload();
                            layer.msg("修改成功!");
                        }else {
                                var index1 = parent.layer.getFrameIndex(window.name);  //获取当前子页面索引
                                parent.layer.close(index1);  //关闭子页面
                                parent.layui.table.reload('waitComplete',{                         //待完善--修改成功后,刷新页面
                                url:uploadurl + '/organization/getOrganizationsByParams',
                                where:{
                                    auditStatus: 1,
                                },
                                cols: [[ //表头
                                    {type:'checkbox',fixed:'left'},
                                    {title: '<span style="color:#000;font-weight:bold;">序号</span>',minWidth:100,templet:function(d){
                                        return d.LAY_INDEX;
                                    }},
                                    {field: 'createTime', title: '<span style="color:#000;font-weight:bold;">录入日期</span>'},
                                    {field: 'name', title: '<span style="color:#000;font-weight:bold;">组织名称</span>'},
                                    {field: 'assign', title: '<span style="color:#000;font-weight:bold;">指派人</span>'},
                                    {field: '',title:'<span style="color:#000;font-weight:bold;">操作</span>',minWidth:170,toolbar:'#waitEventBar',fixed:'right'}           //toolbar-绑定工具条
                                ]],
                            });
                        }
                    } else {
                        layer.msg(msg.msg);
                    }

                }
            });
        }
        return false;
    });

});

function checkorgnamek(obj) {
    if (obj.value != "") {
        $("#orgSearch").click();
    }
}