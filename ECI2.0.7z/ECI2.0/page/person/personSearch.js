//获取用户信息以及视图权限
var view = new viewAuthor(['','personExcel','muchDelete','level']);
var usermess = view.getUserMessage();
window.onload = function(){                   //需要将所用资源加载完毕才能获取到模板引擎（toolBar）
    view.judgeViewAuthor();
}

layui.config({
    base:"../../layui/"
}).extend({
        formSelects:'formSelects-v4'
    });
layui.use(['table','form','laydate','layer','jquery','formSelects'],function(){
    var table = layui.table;
    var form = layui.form;
    var laydate = layui.laydate;
    var layer = layui.layer;
    var $ = layui.jquery;
    var formSelects = layui.formSelects;   
    //主属单位
    formSelects.config('primeCompany',{
        type:"post",  
        header:{                                                                                  //认证信息
            token:usermess.token
        },                                                 
        searchUrl:baseURL_zcw + '/organization/getOrgListByOrgName',
        searchName:'orgName',
        searchVal:'',                                                                              //搜索内容在搜索一次后失效
        delay:500,                                                                                //搜索延迟时间500ms
        direction:'down',
        clearInput:true,
        beforeSearch: function(id,url,searchVal){
            if(searchVal.length<2){
                return false;
            }
            return true;
        },
        beforeSuccess:function(id,url,searchVal,result){
            var data = result.data;
            var arr = [];
            var res = {
                code:result.code,
                msg:result.msg,
            };
            for(var i=0; i<data.length; i++){
                arr[i] = {
                    name:data[i],
                    value:data[i]
                }
            }
            res.data = arr;
            return res;
        },
        success:function(id,url,searchVal,result){
            if(result.code == 0){
                // console.log(result);
            }
            else{             
                layer.tips('未知错误!','#pcTips',{
                    tips:2,
                    time:2000
                });
            }
        }
    });
    
    //表格
    var loadIndex = layer.load(1,{
        shade:[0.1,'#fff']
    });
    var personTable=table.render({
        elem: '#personTable',
        url:baseURL_zcw + '/expert/getList',
        headers:{
          token:usermess.token
        },
        where:{
            createTime: "",
            engaged: "",
            flag: "ALREADY_PASS",
            jobTitle: "",
            name: "",
            primeCompany: "",
            researchDirection: ""
        },
        method:'post',
        contentType:'application/json',
        id:'personTable',
        cellMinWidth:150,
        even:true,
        page:{theme:'#1E9FFF'},
        cols: [[ //表头                             
          {type:'checkbox',fixed:'left'},
          {title: '<span style="color:#000;font-weight:bold;">序号</span>',minWidth:100,fixed:'left',templet:function(d){ 
            return d.LAY_INDEX;
          }},
          {field: 'submitterEmail', title: '<span style="color:#000;font-weight:bold;">提交人</span>',},
          {field: 'submitterDepartment', title: '<span style="color:#000;font-weight:bold;">提交部门</span>'},
          {field: 'submitterOffice', title: '<span style="color:#000;font-weight:bold;">提交科室</span>'},
          {field: 'name', title: '<span style="color:#000;font-weight:bold;">姓名</span>'},
          {field: 'gender', title: '<span style="color:#000;font-weight:bold;">性别</span>'},
          {field: 'country', title: '<span style="color:#000;font-weight:bold;">籍贯</span>',templet:function(d){
              if(d.country == ''){
                return '';
              }
              else if(d.country == '中国'){
                return d.country + '/' + d.province + '/' + d.city;
              }
              else{
                return d.country;
              }
          }},
          {field: 'primeCompany', title: '<span style="color:#000;font-weight:bold;">主属单位</span>'},
          {field: 'department', title: '<span style="color:#000;font-weight:bold;">部门</span>'},
          {field: 'job', title: '<span style="color:#000;font-weight:bold;">职务</span>'},
          {field: 'jobTitle', title: '<span style="color:#000;font-weight:bold;">职称</span>'},
          {field: 'researchDirection', title: '<span style="color:#000;font-weight:bold;">研究方向</span>'},
          {field: 'phoneNumber', title: '<span style="color:#000;font-weight:bold;">固定电话</span>'},
          {field: 'mobileNumber', title: '<span style="color:#000;font-weight:bold;">手机</span>'},
          {field: 'email', title: '<span style="color:#000;font-weight:bold;">邮箱</span>'},
          {field: 'birthday', title: '<span style="color:#000;font-weight:bold;">生日</span>'},
          {field: 'secondCompany', title: '<span style="color:#000;font-weight:bold;">从属单位</span>'},
          {field: 'otherJob', title: '<span style="color:#000;font-weight:bold;">其他重要任职</span>'},
          {field: 'engaged', title: '<span style="color:#000;font-weight:bold;">是否为我司聘任专家</span>',minWidth:170},
          {field: 'remark', title: '<span style="color:#000;font-weight:bold;">备注</span>'},
          {field: 'assign', title: '<span style="color:#000;font-weight:bold;">指派人</span>'},
          {field: 'level', title: '<span style="color:#000;font-weight:bold;">专家等级</span>'},          
          {field: '',title:'<span style="color:#000;font-weight:bold;">操作</span>',minWidth:170,toolbar:'#personToolBar',fixed:'right'}           //toolbar-绑定工具条
        ]],
          response:{                                         //定义后端Json格式
              statusCode:0,
              msgName:"msg",
              dataName:"data",
              countName:'amount'
          },
          request:{
              limitName:'size'
          },
          done:function(res,curr,count){
              layer.close(loadIndex);
              if(!/7/g.test(usermess.viewAuthor)){          //动态添加专家等级
                  $('#personTable').next().find('th[data-field="level"]').css('display','none');
                  $('#personTable').next().find('td[data-field="level"]').css('display','none');
              }  
            }
    });

    //搜索
    form.on('submit(personSearch)',function(obj){
        var field = obj.field;
        personTable.reload({
            where:{
                engaged: field.engaged,
                flag: "ALREADY_PASS",
                jobTitle: field.jobTitle,
                name: field.name,
                level:field.level,
                primeCompany: field.primeCompany,
                researchDirection: field.researchDirection,
                submitterDepartment:field.submitterDepartment,
            }
        })
        return false;
    });

    //Excel导出
    form.on('submit(personExcel)',function(data){
        var URL = window.URL || window.webkitURL;
        var xhr = new XMLHttpRequest();
        xhr.open('post',baseURL_zcw+'/expert/fileExport',true);
        xhr.setRequestHeader('token',usermess.token);    //token认证
        xhr.setRequestHeader('content-type','application/json');
        xhr.responseType = 'blob';              //返回类型blob
        // xhr.responseType = 'arraybuffer';   //返回类型arraybuffer       
        xhr.onload = function(){
            if(this.status == 200){
                var blob = this.response;
                // var blob = new Blob([this.response],"application/octet-stream");
                var url = URL.createObjectURL(blob);
                var a = document.createElement('a');
                a.download = 'expert.xlsx';
                a.href = url;
                $('body').append(a);
                a.click();
                $(a).remove();
            }
        };
        //获取查询条件
        var parameter = {
            flag:'ALREADY_PASS',
        };
        parameter.name = $('#name').val();
        parameter.jobTitle = $('#jobTitle').val();
        parameter.researchDirection = $('#researchDirection').val();
        parameter.engaged = $('#engaged').val();
        var primeCompanyArr = formSelects.value('primeCompany','name')
        parameter.primeCompany = primeCompanyArr[0];
        xhr.send(JSON.stringify(parameter));
    });

    //批量删除
    form.on('submit(muchDelete)',function(obj){
        var checkStatus = table.checkStatus('personTable');
        var checked = checkStatus.data;
        var ids=[];
        $.each(checked,function(index,value){
            ids.push(value.id);
        });
        layer.confirm('<i class="layui-icon" style="font-size:30px;color:red;">&#xe702;&nbsp;&nbsp;</i><city style="font-size:16px;">确定批量删除</city>',
            function(index){
                $.ajax({
                    url:baseURL_zcw+"/expert/delete",
                    type: "post",
                    headers:{
                        token:usermess.token
                    },
                    data:{
                        ids:ids
                    },
                    dataType:'json',
                    traditional:true,                    
                    cache:false,
                    success:function(res){
                        if(res.code == 0){
                            layer.close(index);    //关闭弹框
                            layer.msg("删除成功",{icon:6});
                            personTable.reload({
                                page:{
                                    curr:1
                                }
                            });
                        }
                        else if(res.code == 8){                        
                            layer.msg('权限不足,请确认您的权限范围',{icon:5});
                        }
                        else{                          
                            layer.msg("删除失败",{icon:5});
                        }
                    }
                });
        });
    });
    //监听工具栏
    table.on('tool(personTable)',function(obj){
        var layEvent = obj.event;
        var data = obj.data;
        var tr = obj.tr;

        if(layEvent == 'personEdit'){
            IFrame.open('./personEntry.html',obj)
        }
        else if(layEvent == 'personDelete'){
            var ids=[];
            ids[0]= parseInt(data.id);
            layer.confirm('<i class="layui-icon" style="font-size:30px;color:red;">&#xe702;&nbsp;&nbsp;</i><city style="font-size:16px;">确定删除</city>',
            function(index){
                $.ajax({
                    url:baseURL_zcw+"/expert/delete",
                    type: "post",
                    headers:{
                        token:usermess.token
                    },
                    data:{
                        ids:ids
                    },
                    dataType:'json',
                    traditional:true,
                    cache:false,
                    success:function(res){
                        if(res.code == 0){
                            obj.del();     
                            layer.close(index);   
                            layer.msg("删除成功",{icon:6});
                            personTable.reload();
                        }
                        else if(res.code == 8){                          
                            layer.msg('权限不足,请确认您的权限范围',{icon:5});
                        }
                        else{
                            layer.msg("删除失败",{icon:5});
                        }
                    }
                });
            });
        }

    })
});