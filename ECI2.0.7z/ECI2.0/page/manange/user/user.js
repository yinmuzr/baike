layui.use(['form','layer','laydate','table','laytpl','laypage'],function(){
        var form = layui.form,
            layer = parent.layer === undefined ? layui.layer : top.layer,
            $ = layui.jquery,layer = layui.layer,
            table = layui.table;
    //渲染列表
    var tableIns = table.render({
        elem: '#newsList',
        url: uploadurl + '/user/getListByPage',
        method: 'post',
        request: {
            limitName: 'size'
        },
        response: {
            countName: 'amount'
        },
        headers: {
            token: token
        },
        even: true,
        contentType: 'application/json',
        cellMinWidth: 95,
        page: true,
        height: 'full',
        id: 'newsListTable',
        cols: [[
            {type: "checkbox", fixed:"left"},
            {type: 'numbers', title: '序号', width: 100, fixed:"left"},
            {field: 'email', title: '邮箱号', width: 150},
            {field: 'name', title: '用户名', width: 150},
            {field: 'department', title: '部门'},
            {field: 'office', title: '科室'},
            {field: 'job', title: '职位'},
            {field: 'roleName', title: '角色'},
            {field: 'controlDepartmentName', title: '主管部门'},
            {field: 'isAudit', title: '是否为标准化审核员',templet:'#isAuditdata'},
            {title: '操作', width:140, templet:'#newsListBar',align:"center",fixed:'right'}
        ]]
    });

    // 搜索
    $(".search_btn").on("click",function(){
        table.reload("newsListTable",{
            page: {
                curr: 1 //重新从第 1 页开始
            },
            where: {
                email:$("#email").val()
            }
        })
    });
    //批量删除
    $(".delAll_btn").click(function(){
        var checkStatus = table.checkStatus('newsListTable'),
            data = checkStatus.data,
            newsId = [];
        if(data.length > 0) {
            for (var i in data) {
                newsId.push(data[i].id);
            }
            layer.confirm('确定删除选中的用户？', {icon: 3, title: '提示信息'}, function (index) {
                $.ajax({
                    url:uploadurl+'/user/delete',
                    type:"post",
                    contentType:"application/json",
                    data:JSON.stringify({ids: newsId}),
                    traditional:true,
                    dataType: "json",
                    headers:{
                        token:token
                    },
                    success:function (msg) {
                        if(msg.code==0) {
                            tableIns.reload();
                            layer.close();
                            layer.msg("删除成功！");
                        }else {
                            layer.close(index);
                            layer.msg(msg.msg);
                        }
                    }
                });
            })
        }else{
            layer.msg("请选择需要删除的用户");
        }
    });


    //列表操作  删除 修改
    table.on('tool(newsList)', function(obj){
        var layEvent = obj.event,
            data = obj.data;
        if(layEvent === 'edit'){ //编辑
            edituser(data);
        } else if(layEvent === 'del'){ //删除
            layer.confirm('确定删除此用户？',{icon:3, title:'提示信息'},function(index){
                var idstr=new Array();
                idstr[0]=data.id;
                $.ajax({
                    url:uploadurl+'/user/delete',
                    type:"post",
                    contentType:"application/json",
                    data:JSON.stringify({ids: idstr}),
                    traditional:true,
                    dataType: "json",
                    headers:{
                        token:token
                    },
                    success:function (msg) {
                        if(msg.code==0) {
                            tableIns.reload();
                            layer.close(index);
                            layer.msg("删除成功！");
                        }else {
                            layer.close(index);
                            layer.msg(msg.msg);
                        }
                    }
                });
            });
        }
    });
   // 修改
    function edituser(edit){
        var index = layui.layer.open({
            title : "用户修改",
            type : 2,
            content: '../../manange/user/userupdate.html',
            area:['600px','500px'],
            success : function(layero, index){
                var body = layui.layer.getChildFrame('body', index);
                if(edit){
                    body.find("#addLink").attr("name",edit.id);
                    body.find("#email").val(edit.email);
                    for(var i = 2;i < body.find("[xid=controlDepartment]").children().length-2;i++){
                        if((edit.controlDepartment).indexOf(body.find("[xid=controlDepartment]").children().eq(i)[0].attributes[0].value)!=-1){
                            body.find("[xid=controlDepartment]").children().eq(i).click();
                        }
                    }
                    if(edit.isAudit==0){
                        body.find("#isAudit").next().find("dl dd").eq(2).click();
                    }else {
                        body.find("#isAudit").next().find("dl dd").eq(1).click();
                    }
                    for(var i = 0;i < body.find("#roleName").next().find("dl dd").length;i++){
                        if(edit.roleName==body.find("#roleName").next().find("dl dd").eq(i)[0].innerText){
                            body.find("#roleName").next().find("dl dd").eq(i).click();
                        }
                    }
                    form.render();
                }
            },
            cancel:function () {
                layer.closeAll();
            }
        })
    }

    //add
    $(".addbtn").click(function(){
        var index = layui.layer.open({
            title : "用户添加",
            type : 2,
            content: '../../manange/user/newuser.html',
            area:['600px','500px'],
            success : function(layero, index){
                var body = layui.layer.getChildFrame('body', index);
            },
            cancel:function () {
                layer.closeAll();
            }
        })
    });

});