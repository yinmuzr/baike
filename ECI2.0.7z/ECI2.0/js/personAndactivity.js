// 人员和活动公用方法

//打开子页面
var IFrame = {
    open: function (url, obj) {
        var displayData = this.displayData;
        layerIndex = layer.open({
            id: 'subPage',
            type: 2,
            title: '修改信息',
            area: ['80%', '95%'],
            resize: false,//不允许拉伸
            scrollbar: false,
            content: url,
            success: function (layero, index) {
                var body = layer.getChildFrame('body', index);
                displayData(body, obj, url);
            }
        });
    }
    , close: function () {
        var index = parent.layer.getFrameIndex(window.name);  //获取当前子页面索引
        parent.layer.close(index);  //关闭子页面    
    },
    displayData: function (body, obj, url) {
        var data = obj.data;
        var layEvent = obj.event;
        //活动
        if (/activity/g.test(url)) {
            var inputList = body.find('input');
            for (var i = 0; i < inputList.length; i++) {
                var name = inputList[i].getAttribute('name');
                switch (name) {
                    case 'submitterEmail':
                        $(inputList[i]).attr('value', data.submitterEmail);
                        break; //提交人
                    case 'submitterDepartment':
                        $(inputList[i]).attr('value', data.submitterDepartment);
                        break; //部门
                    case 'submitterOffice':
                        $(inputList[i]).attr('value', data.submitterOffice);
                        break; //科室
                    case 'communicationTheme':
                        $(inputList[i]).attr('value', data.communicationTheme);
                        break; //交流主题
                    case 'detail':
                        $(inputList[i]).attr('value', data.detail);
                        break; //详细地址
                }
            }
            //不显示保存按钮
            body.find('#saveActivity').css('display', 'none');
            //id
            body.find('#id').val(data.id);

            //auditStatus                 
            body.find('#auditStatus').val(data.auditStatus);

            //关键信息
            body.find('#keyMsg').val(data.keyMsg);

            //活动时间
            var activityTime = data.startDate + ' - ' + data.endDate;
            body.find('#activityTime').val(activityTime);

            //活动类型
            var typeSelectDd = body.find('#type').next().find('dl dd');
            for (var i = 0; i < typeSelectDd.length; i++) {
                if ($(typeSelectDd[i]).attr('lay-value') == data.type) {
                    $(typeSelectDd[i]).click();
                }
            }

            //评估意向
            var intentionSelectDd = body.find('#intention').next().find('dl dd');
            for (var i = 0; i < intentionSelectDd.length; i++) {
                if ($(intentionSelectDd[i]).attr('lay-value') == data.intention) {
                    $(intentionSelectDd[i]).click();
                }
            }

            //交流地点
            if (data.country == '中国') {
                var communicatePlace = data.country + '/' + data.province + '/' + data.city;
            } else {
                var communicatePlace = data.country;
            }
            var countryLi = body.find('div[fs_id="communicatePlace"]').find('dl>div').children().eq(0).children();//子页面DOM-国家
            var provinceLi = body.find('div[fs_id="communicatePlace"]').find('dl>div').children().eq(1).children();//子页面DOM-省份
            var cityLi = body.find('div[fs_id="communicatePlace"]').find('dl>div').children().eq(2).children();//子页面DOM-城市
            for (var i = 0; i < countryLi.length; i++) {
                if ($(countryLi[i]).attr('title') == data.country) {
                    $(countryLi[i]).click();
                }
            }
            for (var i = 0; i < provinceLi.length; i++) {
                if ($(provinceLi[i]).attr('title') == data.province) {
                    $(provinceLi[i]).click();
                }
            }
            for (var i = 0; i < cityLi.length; i++) {
                if ($(cityLi[i]).attr('title') == data.city) {
                    $(cityLi[i]).click();
                }
            }
            // var label = body.find('div[fs_id="communicatePlace"]').children().find('div[class="xm-select-title "]').children().eq(0).children().eq(0);
            // label.append('<span fsw="xm-select" value="'+value+'"><font fsw="xm-select">'+communicatePlace+'</font><i class="iconfont icon-close" fsw="xm-select"></i></span>');

            //公司交流人员
            var inCommunicationMan = data.inCommunicationMans.split(';');
            var inCommunicationMans = body.find('dl[xid="inCommunicationMans"]');
            inCommunicationMans.find('[class="xm-select-tips xm-select-none xm-select-empty"]').remove();//删除 没有选项
            $.each(inCommunicationMan, function (index, value) {    //添加回显数据
                inCommunicationMans.append('<dd class="" lay-value="' + value + '"><div class="xm-unselect xm-form-checkbox"><i class="iconfont"></i><span name="' + value + '">' + value + '</span></div></dd>');
                inCommunicationMans.find('[lay-value="' + value + '"]').click();
            });

            //外部交流人员
            if (data.outCommunicationMans != "") {
                var outCommunicationMan = data.outCommunicationMans.split(';');
                var outCommunicationMans = body.find('dl[xid="outCommunicationMans"]');
                outCommunicationMans.find('[class="xm-select-tips xm-select-none xm-select-empty"]').remove();//删除 没有选项
                $.each(outCommunicationMan, function (index, value) {    //添加回显数据
                    outCommunicationMans.append('<dd class="" lay-value="' + value + '"><div class="xm-unselect xm-form-checkbox"><i class="iconfont"></i><span name="' + value + '">' + value + '</span></div></dd>');
                    outCommunicationMans.find('[lay-value="' + value + '"]').click();
                });
            }

            //指定        
            if (data.readables != "") {
                var readable = data.readables.split(';');
                var readables = body.find('dl[xid="readables"]');
                readables.find('[class="xm-select-tips xm-select-none xm-select-empty"]').remove();//删除 没有选项
                $.each(readable, function (index, value) {    //添加回显数据
                    readables.append('<dd class="" lay-value="' + value + '"><div class="xm-unselect xm-form-checkbox"><i class="iconfont"></i><span name="' + value + '">' + value + '</span></div></dd>');
                    readables.find('[lay-value="' + value + '"]').click();
                });
            }

            //会议纪要
            var i = 0;
            var deleteFiles = '';
            var meetingSummary = body.find('div[id="meetingSummary"]');
            meetingSummary.text('');
            $.each(data.fileList, function (index, value) {
                if (value.type == 1) {
                    var div = "<div id='" + index + "'class='multiple-select'><font>" + value.realName + "</font><i id='" + index + "'class='iconfont icon-close'></i></div>";
                    meetingSummary.append(div);
                    i++;
                    //撤销上传文件
                    meetingSummary.find("div i[id=" + index + "]").bind('click', function (e) {
                        deleteFiles = deleteFiles + value.id + ';'
                        body.find('input[id="deleteFiles"]').attr('value', deleteFiles);          //统计删除文件的ID
                        meetingSummary.find("div[id=" + index + "]").remove();                      //删除html中的span
                        if (meetingSummary.children().length == 0) {
                            meetingSummary.text("请上传文件(只支持word、pdf文件)");
                            body.find('input[id="meetingSummary1"]').attr('value', 0);
                        }
                        e.stopPropagation();                                                    //阻止事件冒泡
                    });
                }
            });
            body.find('input[id="meetingSummary1"]').attr('value', i);    //记录修改前会议纪要文件个数(防止表单校验失败)

            var fileList = data.fileList;                           //判断修改前是否有文件
            var mn = false, mpp = false, mp = false;
            for (var i = 0; i < fileList.length; i++) {
                if (fileList[i].type == 0) {
                    mn = true;
                }
                if (fileList[i].type == 3) {
                    mpp = true;
                }
                if (fileList[i].type == 2) {
                    mp = true;
                }
            }

            //会议通知      
            if (mn) {
                var meetingNotice = body.find('div[id="meetingNotice"]');
                meetingNotice.text('');
                $.each(data.fileList, function (index, value) {
                    if (value.type == 0) {
                        var div = "<div id='" + index + "'class='multiple-select'><font>" + value.realName + "</font><i id='" + index + "'class='iconfont icon-close'></i></div>"
                        meetingNotice.append(div);
                        //撤销上传文件
                        meetingNotice.find("div i[id=" + index + "]").bind('click', function (e) {
                            deleteFiles = deleteFiles + value.id + ';'
                            body.find('input[id="deleteFiles"]').attr('value', deleteFiles);          //统计删除文件的ID
                            meetingNotice.find("div[id=" + index + "]").remove();
                            if (meetingNotice.children().length == 0) {
                                meetingNotice.text("请上传文件(只支持word、pdf文件)");
                            }
                            e.stopPropagation();
                        });
                    }
                });
            }
            //会议PPT
            if (mpp) {
                var meetingPPT = body.find('div[id="meetingPPT"]');
                meetingPPT.text('');
                $.each(data.fileList, function (index, value) {
                    if (value.type == 3) {
                        var div = "<div id='" + index + "'class='multiple-select'><font>" + value.realName + "</font><i id='" + index + "'class='iconfont icon-close'></i></div>"
                        meetingPPT.append(div);
                        //撤销上传文件
                        meetingPPT.find("div i[id=" + index + "]").bind('click', function (e) {
                            deleteFiles = deleteFiles + value.id + ';'
                            body.find('input[id="deleteFiles"]').attr('value', deleteFiles);          //统计删除文件的ID
                            meetingPPT.find("div[id=" + index + "]").remove();
                            if (meetingPPT.children().length == 0) {
                                meetingPPT.text("请上传文件(只支持ppt文件)");
                            }
                            e.stopPropagation();
                        });
                    }
                });
            }
            //照片
            if (mp) {
                var meetingPicture = body.find('div[id="meetingPicture"]');
                meetingPicture.text('');
                $.each(data.fileList, function (index, value) {
                    if (value.type == 2) {
                        var imgURL = 'http://172.17.0.6:8090' + value.directory;
                        var span = "<span id='" + index + "'class='multiple-select-picture'><img class='multiple-imgStyle' src='" + imgURL + "'></img><i id='" + index + "'class='iconfont icon-close closeImg'></i></span>"
                        meetingPicture.append(span);
                        meetingPicture.find("span i[id=" + index + "]").css('display', 'inline');
                        //撤销上传照片
                        meetingPicture.find("span i[id=" + index + "]").bind('click', function (e) {
                            deleteFiles = deleteFiles + value.id + ';'
                            body.find('input[id="deleteFiles"]').attr('value', deleteFiles);        //统计删除文件的ID
                            meetingPicture.find("span[id=" + index + "]").remove();
                            if (meetingPicture.children().length == 0) {
                                meetingPicture.text("请上传照片(只支持jpg、png、bmp、jpeg图片)");
                            }
                            e.stopPropagation();                                                  //阻止事件冒泡
                        });
                    }
                });
            }
        }
        //人员
        if (/person/g.test(url)) {
            //id
            body.find('#id').val(data.id);
            //auditStatus                 
            body.find('#auditStatus').val(data.auditStatus);
            //提交人
            body.find('#submitterEmail').val(data.submitterEmail);
            //部门
            body.find('#submitterDepartment').val(data.submitterDepartment);
            //科室
            body.find('#submitterOffice').val(data.submitterOffice);
            //姓名
            body.find('#name').val(data.name);
            //部门
            body.find('#department').val(data.department);
            //职务
            body.find('#job').val(data.job);
            //手机
            body.find('#mobileNumber').val(data.mobileNumber);
            //邮箱
            body.find('#email').val(data.email);
            //固定电话
            body.find('#phoneNumber').val(data.phoneNumber);
            //其它重要任职
            body.find('#otherJob').val(data.otherJob);
            //备注
            body.find('#remark').val(data.remark);
            //研究方向
            var rdSelectDd = body.find('#researchDirection').next().find('dl dd');
            for (var i = 0; i < rdSelectDd.length; i++) {
                if ($(rdSelectDd[i]).attr('lay-value') == data.researchDirection) {
                    $(rdSelectDd[i]).click();
                }
            }
            //职称
            var jtSelectDd = body.find('#jobTitle').next().find('dl dd');
            for (var i = 0; i < jtSelectDd.length; i++) {
                if ($(jtSelectDd[i]).attr('lay-value') == data.jobTitle) {
                    $(jtSelectDd[i]).click();
                }
            }
            //性别
            var genderSelectDd = body.find('#gender').next().find('dl dd');
            for (var i = 0; i < genderSelectDd.length; i++) {
                if ($(genderSelectDd[i]).attr('lay-value') == data.gender) {
                    $(genderSelectDd[i]).click();
                }
            }
            //生日
            // body.find('#birthday').val(data.birthday);
            //籍贯
            if (data.country == '中国') {
                var birthPlace = data.country + '/' + data.province + '/' + data.city;
            } else {
                var birthPlace = data.country;
            }
            var countryLi = body.find('div[fs_id="birthPlace"]').find('dl>div').children().eq(0).children();//子页面DOM-国家
            var provinceLi = body.find('div[fs_id="birthPlace"]').find('dl>div').children().eq(1).children();//子页面DOM-省份
            var cityLi = body.find('div[fs_id="birthPlace"]').find('dl>div').children().eq(2).children();//子页面DOM-城市
            for (var i = 0; i < countryLi.length; i++) {
                if ($(countryLi[i]).attr('title') == data.country) {
                    $(countryLi[i]).click();
                }
            }
            for (var i = 0; i < provinceLi.length; i++) {
                if ($(provinceLi[i]).attr('title') == data.province) {
                    $(provinceLi[i]).click();
                }
            }
            for (var i = 0; i < cityLi.length; i++) {
                if ($(cityLi[i]).attr('title') == data.city) {
                    $(cityLi[i]).click();
                }
            }
            //是否为我司聘任专家
            var engagedSelectDd = body.find('#engaged').next().find('dl dd');
            for (var i = 0; i < engagedSelectDd.length; i++) {
                if ($(engagedSelectDd[i]).attr('lay-value') == data.engaged) {
                    $(engagedSelectDd[i]).click();
                }
            }
            //聘任单位、聘期
            if (data.engaged == '是') {
                body.find('#engagedDepartment').val(data.engagedDepartment);
                body.find('#engagedTerm').val(data.engagedTerm);
            }
            //主属单位
            var primeCompany = data.primeCompany.split(';');
            var primeCompanyId = body.find('dl[xid="primeCompanyId"]');
            primeCompanyId.find('[class="xm-select-tips xm-select-none xm-select-empty"]').remove();//删除 没有选项
            $.each(primeCompany, function (index, value) {    //添加回显数据
                primeCompanyId.append('<dd class="" lay-value="' + value + '"><div class="xm-unselect xm-form-checkbox"><i class="iconfont"></i><span name="' + value + '">' + value + '</span></div></dd>');
                primeCompanyId.find('[lay-value="' + value + '"]').click();
            });
            //从属单位
            if (data.secondCompany != null) {
                var secondCompanyId = data.secondCompany.split(';');
                var secondCompanyIds = body.find('dl[xid="secondCompanyIds"]');
                secondCompanyIds.find('[class="xm-select-tips xm-select-none xm-select-empty"]').remove();//删除 没有选项
                $.each(secondCompanyId, function (index, value) {    //添加回显数据
                    secondCompanyIds.append('<dd class="" lay-value="' + value + '"><div class="xm-unselect xm-form-checkbox"><i class="iconfont"></i><span name="' + value + '">' + value + '</span></div></dd>');
                    secondCompanyIds.find('[lay-value="' + value + '"]').click();
                });
            }
            //指定
            if (data.readables != "") {
                var readable = data.readables.split(';');
                var readables = body.find('dl[xid="readables"]');
                readables.find('[class="xm-select-tips xm-select-none xm-select-empty"]').remove();//删除 没有选项
                $.each(readable, function (index, value) {    //添加回显数据
                    readables.append('<dd class="" lay-value="' + value + '"><div class="xm-unselect xm-form-checkbox"><i class="iconfont"></i><span name="' + value + '">' + value + '</span></div></dd>');
                    readables.find('[lay-value="' + value + '"]').click();
                });
            }
            //照片
            if (data.picture != '') {
                var previewImg = body.find('img[id="previewImg"]');
                var image = 'http://172.17.0.1:8085' + data.picture;
                previewImg.attr('src', image);
                // var i = "<i id='closeImg' class='iconfont icon-close closeImg'></i>"                //删除照片功能
                // previewImg.parent().append(i);
                // previewImg.siblings().bind('click',function(e){
                //     previewImg.attr('src','../../images/add.png');                    
                //     previewImg.parent().find('i').remove();
                //     e.stopPropagation();
                // });
            }
            //是否禁止提交按钮
            if (layEvent == 'detail') {
                body.find('#submitPerson').attr('class', 'layui-btn layui-btn-normal layui-btn-lg layui-btn-disabled submit-btn');
                body.find("#submitPerson").prop('disabled', true);
            }
        }
//组织
        if (/org/g.test(url)) {
            body.find("#filediv").hide();
            body.find("#submitorg")[0].innerText = "完善信息";
            body.find("#name").val(data.name);
            body.find("#primeBusiness").val(data.primeBusiness);
            body.find("#legalPerson").val(data.legalPerson);
            body.find("#remark").val(data.remark);
            body.find("#getid").attr("name", data.id);
            body.find("#detail").val(data.detail);

            //我司入会？
            if (data.companyEngaged == 1) {
                body.find("#companyEngaged").next().find("dl dd").eq(1).click();
                body.find("#companyTerm").val(data.companyTerm);
                for (var i = 0; i < body.find("#companyLevel").next().find("dl dd").length; i++) {
                    if (data.companyLevel == body.find("#companyLevel").next().find("dl dd").eq(i)[0].innerText) {
                        body.find("#companyLevel").next().find("dl dd").eq(i).click();
                    }
                }
            } else {
                body.find("#companyEngaged").next().find("dl dd").eq(2).click();
            }
            //
            //我司人员入会？
            if (data.leaderEngaged == 1) {
                body.find("#leaderEngaged").next().find("dl dd").eq(1).click();
                body.find("#leaderName").val(data.leaderName);
                body.find("#leaderTerm").val(data.leaderTerm);
                for (var i = 0; i < body.find("#leaderJob").next().find("dl dd").length; i++) {
                    if (data.leaderJob == body.find("#leaderJob").next().find("dl dd").eq(i)[0].innerText) {
                        body.find("#leaderJob").next().find("dl dd").eq(i).click();
                    }
                }
            } else {
                body.find("#leaderEngaged").next().find("dl dd").eq(2).click();
            }

            // typelevel
            var clicknodetypelevel = body.find("[xid=typelevel]").children().children();
            // this.clickconditons(clicknodetypelevel,1,data.level,data.type);
            //typelevel-type
            for (var i = 0; i < clicknodetypelevel.eq(0).children().length; i++) {
                if (data.type == clicknodetypelevel.eq(0).children().eq(i)[0].innerText) {
                    clicknodetypelevel.eq(0).children().eq(i).trigger('click');
                }
            }
            //typelevel-level
            for (var i = 0; i < clicknodetypelevel.eq(1).children().length; i++) {
                if (data.level == clicknodetypelevel.eq(1).children().eq(i)[0].innerText && data.type == clicknodetypelevel.eq(1).children().eq(i)[0].attributes.pid.value) {
                    clicknodetypelevel.eq(1).children().eq(i).trigger('click');
                }
            }

            //provincecity
            // var clicknode = body.find("[xid=provincecity]").children().children();
            // console.log(body.find("dl[xid=provincecity]").children());
            // // this.clickoption(clicknode, 0, data.country);
            // if (data.country !== "") {
            //     for (var i = 0; i < clicknode.children().length; i++) {
            //         if (data.country == clicknode.children().eq(i)[0].title) {
            //             // console.log(clicknode.eq(2).children().eq(i));
            //             clicknode.children().eq(i)[0].click();
            //         }
            //     }
            // }
            // var jnum = 0;
            // if (data.province !== "") {
            //     // var jnum = this.clickoption(clicknode,1,data.province);
            //     for (var i = 0; i < clicknode.eq(1).children().length; i++) {
            //         if (data.province == clicknode.eq(1).children().eq(i)[0].title) {
            //             clicknode.eq(1).children().eq(i).click();
            //             jnum = i;
            //         }
            //     }
            // }
            // if (data.city !== "") {
            //     // this.clickconditons(clicknode, 2, data.city, clicknode.eq(1).children().eq(jnum)[0].attributes.value.value);
            //     for (var i = 0; i < clicknode.eq(2).children().length; i++) {
            //         if ((data.city == clicknode.eq(2).children().eq(i)[0].title) && (clicknode.eq(1).children().eq(jnum)[0].attributes.value.value == clicknode.eq(2).children().eq(i)[0].attributes.pid.value)) {
            //             // console.log(clicknode.eq(2).children().eq(i));
            //             clicknode.eq(2).children().eq(i).click();
            //         }
            //     }
            //
            // }
            var countryLi = body.find('div[fs_id="provincecity"]').find('dl>div').children().eq(0).children();//子页面DOM-国家
            var provinceLi = body.find('div[fs_id="provincecity"]').find('dl>div').children().eq(1).children();//子页面DOM-省份
            var cityLi = body.find('div[fs_id="provincecity"]').find('dl>div').children().eq(2).children();//子页面DOM-城市
            console.log(countryLi);
            for (var i = 0; i < countryLi.length; i++) {
                if ($(countryLi[i]).attr('title') == data.country) {
                    $(countryLi[i]).click();
                }
            }
            for (var i = 0; i < provinceLi.length; i++) {
                if ($(provinceLi[i]).attr('title') == data.province) {
                    $(provinceLi[i]).click();
                }
            }
            for (var i = 0; i < cityLi.length; i++) {
                if ($(cityLi[i]).attr('title') == data.city) {
                    $(cityLi[i]).click();
                }
            }
        }
    }
};

//权限管理
function viewAuthor(arrId){
    if(arrId!= undefined){
        if(arrId[0] == undefined || arrId[0] == ''){
            this.muchPass = '';        
        }else{
            this.muchPass = '#'+ arrId[0];
        }
        if(arrId[1] == undefined){
            this.ExcelId = '';        
        }else{
            this.ExcelId = '#' + arrId[1];
        }
        if(arrId[2] == undefined){
            this.muchDelete = '';        
        }else{
            this.muchDelete = '#' + arrId[2];
        }
        if(arrId[3] == undefined){
            this.level = '';        
        }else{
            this.level = '#' + arrId[3];
        }
    }
}

viewAuthor.prototype = {
    constructor : viewAuthor,
    getUserMessage : function(){
        return JSON.parse(sessionStorage.getItem('usermess'));
    },
    judgeViewAuthor : function(){
        var usermess = this.getUserMessage();
        var viewAuthorValues = usermess.viewAuthor; 
        var baseAuthorValues = usermess.baseAuthor;
        // console.log(usermess);
        //web后台管理
        if(/1/g.test(viewAuthorValues)){    
            $('#navBar').children().children().eq(4).css('display','block');            
        }else{
            $('#navBar').children().children().eq(4).css('display','none');                        
        }
        //文件导出       
        if(/2/g.test(viewAuthorValues)){
            $(this.ExcelId).parent().css('display','block');
            $(this.ExcelId).css('display','inline-block');
        }else{
            $(this.ExcelId).css('display','none');
        }   
        //待评定     
        if(/3/g.test(viewAuthorValues)){    
            $('#navBar').children().children().eq(3).find('dd').eq(3).css('display','block');            
        }else{
            $('#navBar').children().children().eq(3).find('dd').eq(3).css('display','none');                        
        }
        //信息删除       
        if(/4/g.test(viewAuthorValues)){
            $(this.muchDelete).parent().css('display','block');                                          
            $(this.muchDelete).css('display','inline-block');     //批量删除
            $('#personToolBar').text('<a class="layui-btn layui-btn-normal layui-btn-xs" lay-event="personEdit">修改</a><a class="layui-btn layui-btn-danger layui-btn-xs" lay-event="personDelete">删除</a>');//人员删除（能做信息删除的一定能够信息所有人信息）                    
            $('#activityToolBar').text('<a class="layui-btn layui-btn-normal layui-btn-xs" lay-event="activityEdit">修改</a><a class="layui-btn layui-btn-danger layui-btn-xs" lay-event="activityDelete">删除</a>');//活动删除 
            $('#orgToolBar').text('<a class="layui-btn layui-btn-xs" lay-event="edit">编辑</a><a class="layui-btn layui-btn-xs layui-btn-danger" lay-event="del">删除</a>');//组织删除
        }else{
            $(this.muchDelete).css('display','none');
            if(/8/g.test(baseAuthorValues)){        //修改所有人信息(可能无需判断)
                $('#personToolBar').text('<a class="layui-btn layui-btn-normal layui-btn-xs" lay-event="personEdit">修改</a>');    
                $('#activityToolBar').text('<a class="layui-btn layui-btn-normal layui-btn-xs" lay-event="activityEdit">修改</a>');
                $('#orgToolBar').text('<a class="layui-btn layui-btn-xs" lay-event="edit">编辑</a>');
            }else{
                if(/7/g.test(baseAuthorValues)){   //修改自己提交的信息
                    $('#personToolBar').text('{{#if(d.submitterEmail == '+usermess.email+') {  }}<a class="layui-btn layui-btn-normal layui-btn-xs" lay-event="personEdit">修改</a>{{# } else{ }}<a class="layui-btn layui-btn-xs layui-btn-disabled" lay-event="">修改</a>{{#} }} ');                                              
                    $('#activityToolBar').text('{{#if(d.submitterEmail == '+usermess.email+') {  }}<a class="layui-btn layui-btn-normal layui-btn-xs" lay-event="activityEdit">修改</a>{{# } else{ }}<a class="layui-btn layui-btn-xs layui-btn-disabled" lay-event="">修改</a>{{#} }} ');
                    $('#orgToolBar').text('{{#if(d.submitterEmail == '+usermess.email+') {  }}<a class="layui-btn layui-btn-xs" lay-event="edit">编辑</a>{{# } else{ }}<a class="layui-btn layui-btn-xs layui-btn-disabled" lay-event="edit">编辑</a>{{#} }} ');
                }
            }
        }
        //信息审核        
        if(/5/g.test(viewAuthorValues)){    
            $(this.muchPass).parent().css('display','block'); //批量通过                        
            $('#waitReviewToolBar').text('{{#if(d.submitterEmail == '+usermess.email+') {  }}<a class="layui-btn layui-btn-normal layui-btn-xs" lay-event="modify">修改</a><a class="layui-btn layui-btn-xs" style="width:50px;" lay-event="pass">通过</a><a class="layui-btn layui-btn-danger layui-btn-xs" style="width:50px;" lay-event="reject">驳回</a>{{# } else{ }}<a class="layui-btn layui-btn-xs layui-btn-disabled" lay-event="">修改</a><a class="layui-btn layui-btn-xs" style="width:50px;" lay-event="pass">通过</a><a class="layui-btn layui-btn-danger layui-btn-xs" style="width:50px;" lay-event="reject">驳回</a>{{#} }} ');//通过和驳回
        }else{
            $(this.muchPass).parent().css('display','none');  
            if(/8/g.test(baseAuthorValues)){        //修改所有人信息(可能无需判断)
                $('#waitReviewToolBar').text('<a class="layui-btn layui-btn-normal layui-btn-xs" style="width:50px;" lay-event="modify">修改</a>');                                                         
            }else{
                if(/7/g.test(baseAuthorValues)){   //修改自己提交的信息
                    $('#waitReviewToolBar').text('{{#if(d.submitterEmail == '+usermess.email+') {  }}<a class="layui-btn layui-btn-normal layui-btn-xs" style="width:50px;" lay-event="modify">修改</a>{{# } else{ }}<a class="layui-btn layui-btn-xs layui-btn-disabled" style="width:50px;" lay-event="">修改</a>{{#} }} ');                                                                                                                                      
                }
            }                    
        }
        //专家等级查询        
        if(/7/g.test(viewAuthorValues)){   
            $(this.level).parent().parent().parent().css('display','block');  
        }else{
            $(this.level).parent().parent().parent().css('display','none');                              
        } 
        //待审核      
        if(/8/g.test(viewAuthorValues)){    
            $('#navBar').children().children().eq(3).find('dd').eq(1).css('display','block');                    
        }else{
            $('#navBar').children().children().eq(3).find('dd').eq(1).css('display','none');                                
        }
        //被驳回     
        if(/9/g.test(viewAuthorValues)){    
            $('#navBar').children().children().eq(3).find('dd').eq(2).css('display','block');                    
        }else{
            $('#navBar').children().children().eq(3).find('dd').eq(2).css('display','none');                                
        }
    }
}






   

