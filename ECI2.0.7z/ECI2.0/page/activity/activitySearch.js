//获取用户信息以及视图权限
var view = new viewAuthor(['','activityExcel','muchDelete']);
var usermess = view.getUserMessage();
window.onload = function(){
    view.judgeViewAuthor();
};

layui.config({
    base:"../../layui/"
}).extend({
        formSelects:'formSelects-v4'
    });
layui.use(['table','form','laydate','layer','jquery','formSelects'],function(){
    var table = layui.table;
    var form = layui.form;
    var laydate = layui.laydate;
    var layer = layui.layer;
    var $ = layui.jquery;
    var formSelects = layui.formSelects;
    // 活动时间
    var activityTime = laydate.render({
        elem:'#activityTime',
        range:true
    });
    // 公司交流人员
    formSelects.config('inCommunicationMan',{
        type:"post",
        header:{                                                                                  //认证信息
            token:usermess.token
        },                                                    
        searchUrl:baseURL_lbq + '/contacts/queryPerson',
        searchName:'name',
        searchVal:'',                                                                              //搜索内容在搜索一次后失效
        delay:500,                                                                                //搜索延迟时间500ms
        direction:'down',
        clearInput:true,
        beforeSearch: function(id,url,searchVal){
            if(!/^[\u4E00-\u9FA5]{2,}$/g.test(searchVal)){                                       //两位中文以上触发
                return false;
            }
            return true;
        },
        beforeSuccess:function(id,url,searchVal,result){
            var data = result.data;
            var arr = [];
            var res = {
                code:result.code,
                msg:result.msg,
            };
            for(var i=0; i<data.length; i++){
                arr[i] = {
                    name:data[i],
                    value:data[i]
                }
            }
            res.data = arr;
            return res;
        },
        success:function(id,url,searchVal,result){
            if(result.code == 0){
                // console.log(result);
            }
            else{             
                layer.tips('未知错误!','#icmTips',{
                    tips:2,
                    time:2000
                });
            }
        }
    });
    
    //表格
    var loadIndex = layer.load(1,{
        shade:[0.1,'#fff']
    });
    var activityTable=table.render({
        elem: '#activityTable',
        url:baseURL_zcw + '/activity/getActivitiesByParams',
        headers:{
          token:usermess.token
        },
        where:{
            auditStatus:2   //查询--已通过
        },
        method:'post',
        contentType:'application/json',
        id:'activityTable',
        cellMinWidth:150,
        even:'true',  
        page:{theme:'#1E9FFF'},
        cols: [[ //表头                             
          {type:'checkbox',fixed:'left'},
          {title: '<span style="color:#000;font-weight:bold;">序号</span>',minWidth:100,fixed:'left',templet:function(d){ 
            return d.LAY_INDEX;
          }},
          {field: 'code', title: '<span style="color:#000;font-weight:bold;">系统编号</span>',minWidth:100,fixed:'left'},
          {field: 'submitterEmail', title: '<span style="color:#000;font-weight:bold;">提交人</span>'},
          {field: 'submitterDepartment', title: '<span style="color:#000;font-weight:bold;">提交部门</span>'},
          {field: 'submitterOffice', title: '<span style="color:#000;font-weight:bold;">提交科室</span>'},
          {field: 'type', title: '<span style="color:#000;font-weight:bold;">活动类型</span>'},
          {field: 'communicationTheme', title: '<span style="color:#000;font-weight:bold;">交流主题</span>',minWidth:300},
          {field: 'startDate', title: '<span style="color:#000;font-weight:bold;">活动时间</span>',minWidth:300,templet:function(d){
            return d.startDate + ' - ' + d.endDate;
          }},
          {field: 'country', title: '<span style="color:#000;font-weight:bold;">交流地点</span>',templet:function(d){
            if(d.country == '中国'){
                return d.country + '/' + d.province + '/' + d.city;
            }else{
                return d.country;
            }
          }},
          {field: 'keyMsg', title: '<span style="color:#000;font-weight:bold;">关键信息</span>',minWidth:300},
          {field: 'intention', title: '<span style="color:#000;font-weight:bold;">评估意向</span>'},
          {field: 'inCommunicationMans', title: '<span style="color:#000;font-weight:bold;">公司交流人员</span>',minWidth:400},
          {field: 'outCommunicationMans', title: '<span style="color:#000;font-weight:bold;">外部交流人员</span>',minWidth:400},
          {field: 'readables', title: '<span style="color:#000;font-weight:bold;">指定</span>',minWidth:400},
          {field: 'msFiles', title: '<span style="color:#000;font-weight:bold;">会议纪要</span>',minWidth:400,templet:function(d){
              var a = '';
              $.each(d.fileList,function(index,value){
                if(value.type == 1){
                    var href = 'http://172.17.0.6:8090'+value.directory;
                    a = a+ '<div class="searchFileStyle"><a href="'+href+'">'+value.realName+'</a></div>';                          
                }
              });         
              return a;
          }},
          {field: 'mnFiles', title: '<span style="color:#000;font-weight:bold;">会议通知</span>',minWidth:400,templet:function(d){
                var a = '';
                $.each(d.fileList,function(index,value){
                if(value.type == 0){
                    var href = 'http://172.17.0.6:8090'+value.directory;
                    a = a+ '<div class="searchFileStyle"><a href="'+href+'">'+value.realName+'</a></div>';                          
                }
                });         
                return a;
            }},
          {field: 'mpFiles', title: '<span style="color:#000;font-weight:bold;">照片</span>',minWidth:400,templet:function(d){
                var a = '';
                $.each(d.fileList,function(index,value){
                if(value.type == 2){
                    var href = 'http://172.17.0.6:8090'+value.directory;
                    a = a+ '<div class="searchFileStyle"><a target="_blank" href="'+href+'">'+value.realName+'</a></div>';                          
                }
                });         
                return a;
           }},
          {field: 'mppFiles', title: '<span style="color:#000;font-weight:bold;">会议PPT</span>',minWidth:400,templet:function(d){
                var a = '';
                $.each(d.fileList,function(index,value){
                if(value.type == 3){
                    var href = 'http://172.17.0.6:8090'+value.directory;
                    a = a+ '<div class="searchFileStyle"><a href="'+href+'">'+value.realName+'</a></div>';                          
                }
                });         
                return a;
          }},
          {field: 'assign', title: '<span style="color:#000;font-weight:bold;">指派人</span>'},
          {title:'<span style="color:#000;font-weight:bold;">操作</span>',minWidth:170,toolbar:'#activityToolBar',fixed:'right'}           //toolbar-绑定工具条
        ]],
          request:{
            limitName:'size'
          },
          response:{                                         //定义后端Json格式
              statusCode:0,
              msgName:"msg",
              dataName:"data",
              countName:'amount'
          },
          done:function(res,curr,count){
              layer.close(loadIndex);
            }
      });

        //查询
        form.on('submit(activitySearch)',function(data){
            var field = data.field;
            var activityTime = field.activityTime.split(' - ');
            var startDate = activityTime[0];
            var endDate = activityTime[1];
            activityTable.reload({
                where:{
                    auditStatus:2,
                    type:field.type,
                    startDate:startDate,
                    endDate:endDate,
                    theme:field.theme,
                    intention:field.intention,
                    submitterDepartment:field.submitterDepartment,
                    inCommunicationMan:field.inCommunicationMan
                }
            })
            return false;
        });

        //Excel导出
        form.on('submit(activityExcel)',function(data){
            var URL = window.URL || window.webkitURL;
            var xhr = new XMLHttpRequest();
            xhr.open('post',baseURL_lbq+'/activity/fileExport',true);
            xhr.setRequestHeader('token',usermess.token);    //token认证
            xhr.setRequestHeader('content-type','application/json');
            xhr.responseType = 'blob';              //返回类型blob
            xhr.onload = function(){
                if(this.status == 200){
                    var blob = this.response;
                    var url = URL.createObjectURL(blob);
                    var a = document.createElement('a');
                    a.download = 'activity.xlsx';
                    // a.href = e.target.result;
                    a.href = url;
                    $('body').append(a);
                    a.click();
                    $(a).remove();
                }
            };
            //获取查询条件
            var parameter = {
                auditStatus:2
            };
            parameter.type = $('#type').val();
            parameter.theme = $('#theme').val();
            parameter.submitterDepartment = $('#submitterDepartment').val();
            parameter.intention = $('#intention').val();
            var inCommunicationManArr = formSelects.value('inCommunicationMan','name')
            parameter.inCommunicationMan = inCommunicationManArr[0];
            var activityTime = $('#activityTime').val();
            var activityTimeArr = activityTime.split(' - ');
            parameter.startDate = activityTimeArr[0];
            parameter.endDate = activityTimeArr[1];
            xhr.send(JSON.stringify(parameter));            //发送数据
        });

        //批量删除
        form.on('submit(muchDelete)',function(data){
            var checkStatus = table.checkStatus('activityTable');
            var data = checkStatus.data;
            var delId ={
                ids:[]
            };
            $.each(data,function(index,value){
                delId.ids.push(value.id);
            });
            layer.confirm('<i class="layui-icon" style="font-size:30px;color:red;">&#xe702;&nbsp;&nbsp;</i><city style="font-size:16px;">确定批量删除</city>',
              function(index){
                $.ajax({
                    url:baseURL_lbq+"/activity/deleteActivity",
                    type: "post",
                    headers:{
                        token:usermess.token
                    },
                    data:JSON.stringify(delId),
                    dataType:'json',
                    contentType:'application/json',
                    cache:false,
                    success:function(res){
                        if(res.code == 0){
                            layer.close(index);    //关闭弹框
                            layer.msg("删除成功",{icon:6});
                            activityTable.reload({
                                page:{
                                    curr:1
                                }
                            });
                        }
                        else if(res.code == 8){                        
                            layer.msg('权限不足,请确认您的权限范围',{icon:5});
                        }
                        else{
                            layer.msg("删除失败",{icon:5});
                        }
                    }
                });
            });
            return false;
        })
      //工具栏(编辑和删除)
      table.on('tool(activityTable)',function(obj){
          var data = obj.data;
          var tr = obj.tr;
          var layEvent = obj.event;
          if(layEvent == 'activityEdit'){
            IFrame.open('./activityEntry.html',obj)
          }
          else if(layEvent == 'activityDelete'){
            var delId ={
                ids:[]
            };
            delId.ids[0]=data.id;
            layer.confirm('<i class="layui-icon" style="font-size:30px;color:red;">&#xe702;&nbsp;&nbsp;</i><city style="font-size:16px;">确定删除</city>',
                function(index){
                  $.ajax({
                    url:baseURL_lbq+"/activity/deleteActivity",
                    type: "post",
                    headers:{
                        token:usermess.token
                    },
                    data:JSON.stringify(delId),
                    dataType:'json',
                    contentType:'application/json',
                    cache:false,
                    success:function(res){
                        if(res.code == 0){
                            obj.del();             //删除这一行
                            layer.close(index);    //关闭弹框
                            layer.msg("删除成功",{icon:6});
                            activityTable.reload();
                        }
                        else if(res.code == 8){                        
                            layer.msg('权限不足,请确认您的权限范围',{icon:5});
                        }
                        else{
                            layer.msg("删除失败",{icon:5});
                        }
                    }
                });
            });
          }
      })
});