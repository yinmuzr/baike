//获取用户信息及视图权限
var view = new viewAuthor(['muchPass']);
var usermess = view.getUserMessage();

layui.use(['form','table','laydate'],function(){
    var form = layui.form;
    var table = layui.table;
    var laydate = layui.laydate;
    var isAssess = $('#isAssess').val();
    //录入日期
    var createTime = laydate.render({
        elem:'#createTime'
    });

    var loadIndex = layer.load(1,{
      shade:[0.1,'#fff']
    });
    var waitAssess=table.render({
        elem: '#waitAssess',
        url:baseURL_zcw + '/expert/getList',
        headers:{
          token:usermess.token
        },
        where:{
          flag: "WAIT_ASSESS",
          isAssess:isAssess
        },
        method:'post',
        contentType:'application/json',
        id:'waitAssess',
        cellMinWidth:150,
        // even:true,
        page:{theme:'#1E9FFF'},
        cols: [[ //表头                             
          {type:'checkbox',fixed:'left'},
          {title: '<span style="color:#000;font-weight:bold;">序号</span>',width:80,templet:function(d){ 
            return d.LAY_INDEX;
          }},
          {field: 'createTime', title: '<span style="color:#000;font-weight:bold;">录入日期</span>',},
          {field: 'name', title: '<span style="color:#000;font-weight:bold;">姓名</span>'},
          {field: 'primeCompany', title: '<span style="color:#000;font-weight:bold;">主属单位</span>'},
          {field: '',title:'<span style="color:#000;font-weight:bold;">详情</span>',width:150,toolbar:'#detail',},         
          {field: 'level', title: '<span style="color:#000;font-weight:bold;">级别评定</span>',event:'levelEvent',templet:'#levelTemplet'},
          {field: 'dockingDepartment', title: '<span style="color:#000;font-weight:bold;">对接部门</span>',event:'dockingDepartmentEvent',templet:'#dockingDepartmentTemplet'},
          {field: '',title:'<span style="color:#000;font-weight:bold;">操作</span>',width:150,toolbar:'#waitEventBar',},                   
        ]],
          response:{                                         //定义后端Json格式
              statusCode:0,
              msgName:"msg",
              dataName:"data",
              countName:'amount'
          },
          request:{
              limitName:'size'
          },
          done:function(res,curr,count){
              layer.close(loadIndex);
            }
    });

    //绑定下拉框点击事件(百度的。。。受教了)
    (function(doc,o){
        var tk,obj,otd,callback;
        o.show = function(h,e,c){
        callback = c;
        if(doc.getElementById('table_select')){
            doc.getElementById('table_select').remove();
        }
        otd = e;
        var s = '<div id="table_select" class="table-select"><dl class="layui-anim layui-anim-upbit" style="padding: 0px;top: 0px">';
        for(var k in h.data){
            if(h.value == h.data[k].value){
            s += '<dd lay-value="'+ h.data[k].value + '" class="layui-this">'+ h.data[k].text + '</dd>';
            }else{
            s += '<dd lay-value="'+ h.data[k].value + '" >'+ h.data[k].text + '</dd>';
            }
        }
        s += '</dl></div>';
        otd.innerHTML = s + otd.innerHTML;
        obj = doc.getElementById('table_select');
        obj.onmouseout = function(){
            tk = 1;
            setTimeout(function() {
            if(tk){
                if(obj){
                ke = 0;
                obj.remove();
                }
            }
            }, 200);
        }
        obj.onmouseover = function(){
            tk = 0;
        }
        obj.addEventListener('click', function(e){
            var value = $(e.srcElement).attr('lay-value');
            obj.remove();
            callback(value);
        });
        }
    })(document, window.tableSelect = {});


    //监听工具栏
    table.on('tool(waitAssess)',function(obj){
        var data = obj.data;
        var layEvent = obj.event;
        var tr = obj.tr;
        if(layEvent == 'detail'){
            IFrame.open('../../person/personEntry.html',obj);
        }
        else if(layEvent == 'waitAssess'){
            var Data = {ids:[]};
            Data.ids[0]=data.id;
            Data.level = data.level;
            Data.dockingDepartment = data.dockingDepartment;
            if(data.dockingDepartment == "" || data.level == 0){
                layer.tips('提交信息不能为空','#waitAssessSubmit-'+data.id,{
                    tips:2,
                    time:2000
                });
            }else{
                $.ajax({
                    url:baseURL_zcw + '/expert/assess',
                    type:'POST',
                    headers:{
                      token:usermess.token
                    },
                    contentType:'application/json',
                    cache:false,
                    dataType:'json',
                    traditional:true,
                    data:JSON.stringify(Data),
                    success:function(res){
                        if(res.code == 0){
                          layer.msg("提交成功");
                          waitAssess.reload({
                                where:{
                                    flag: "WAIT_ASSESS",
                                    isAssess:$('#isAssess').val(),
                                    createTime:$('#createTime').val()  
                                }
                            });
                        }
                        else{
                          layer.msg("提交失败");
                        }
                    }
                });
            }
        }
        else if(layEvent === 'levelEvent'){
            //显示下拉框框
            tableSelect.show({
              value:obj.data.level, //初始化时默认值(selected)
              data:[{               //下拉选择项(option)
                value: '0',
                text: '暂未评级'
              },{
                value: '1',
                text: '☆'
              },{
                value: '2',
                text: '☆☆'
              },{
                value: '3',
                text: '☆☆☆'
              },{
                value: '4',
                text: '☆☆☆☆'
              },{
                value: '5',
                text: '☆☆☆☆☆'
              }]},
               this, 
               function(val){        //回调函数 返回结果
                obj.data.level = val;
                obj.update(obj.data);
                form.render();
              }
            );
        }
        else if(layEvent === 'dockingDepartmentEvent'){
            //显示下拉框框
            tableSelect.show({
              value:obj.data.dockingDepartment, //初始化时默认值(selected)
              //下拉选择项(option)
              data:[
                {value: '',text: '请选择'},{value: '知识产权办公室',text: '知识产权办公室'},{value: '标准管理部',text: '标准管理部'},{value: '出口技术部',text: '出口技术部'},
                {value: '家用空调技术部',text: '家用空调技术部'},{value: '机电技术研究院',text: '机电技术研究院'},{value: '电机系统技术研究院',text: '电机系统技术研究院'},{value: '装备动力技术研究院',text: '装备动力技术研究院'},
                {value: '工艺部',text: '工艺部'},{value: '检测中心',text: '检测中心'},{value: '工业设计中心',text: '工业设计中心'},{value: '通信技术研究院',text: '通信技术研究院'},
                {value: '制冷技术研究院',text: '制冷技术研究院'},{value: '家电技术研究一院',text: '家电技术研究一院'},{value: '计算机中心',text: '计算机中心'},{value: '大数据中心',text: '大数据中心'},
                {value: '商用空调技术一部',text: '商用空调技术一部'},{value: '商用空调技术二部',text: '商用空调技术二部'},{value: '新能源环境技术研究院',text: '新能源环境技术研究院'},{value: '物联网研究院',text: '物联网研究院'},
                {value: '家电技术研究二院',text: '家电技术研究二院'}
              ]},
               this, 
               function(val){        //回调函数 返回结果
                obj.data.dockingDepartment = val;
                obj.update(obj.data);
                form.render();
              }
            );
        }
    });

    //监听搜索按钮
    form.on('submit(waitAssessSearch)',function(obj){
        var field = obj.field;
        waitAssess.reload({
            where:{
              flag: "WAIT_ASSESS",
              isAssess:field.isAssess,
              createTime:field.createTime
            }
        });
        return false;
    });

    //批量评定
    form.on('submit(muchAssess)',function(obj){
        var field = obj.field;
        var checkStatus = table.checkStatus('waitAssess');
        var data = checkStatus.data;
        var DATA = {
            level:field.levels,
            dockingDepartment:field.dockingDepartments,
            ids:[]
        };
        $.each(data,function(index,value){
            DATA.ids.push(value.id);
        });
        $.ajax({
            url:baseURL_zcw + '/expert/assess',
            type:'POST',
            headers:{
                token:usermess.token
            },
            dataType:'json',
            cache:false,
            traditional:true,
            contentType:'application/json',
            data:JSON.stringify(DATA),
            success:function(res){
                if(res.code == 0){
                    layer.msg('批量评定成功');
                    waitAssess.reload({
                        where:{
                            flag: "WAIT_ASSESS",
                            isAssess:$('#isAssess').val(),
                            createTime:$('#createTime').val()  
                        }
                    });
                }else{
                    layer.msg('批量评定失败');
                }
            }
        })
        return false;
    });
});