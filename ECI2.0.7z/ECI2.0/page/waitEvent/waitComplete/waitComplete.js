//获取用户信息及视图权限
var view = new viewAuthor(['muchPass']);
var usermess = view.getUserMessage();

layui.use(['form','table'],function(){
    var form = layui.form;
    var table = layui.table;

    var loadIndex = layer.load(1,{
      shade:[0.1,'#fff']
    });
    var waitComplete=table.render({
        elem: '#waitComplete',
        url:baseURL_zcw + '/expert/getList',
        headers:{
          token:usermess.token
        },
        where:{
          flag: "WAIT_COMPLETE",
        },
        method:'post',
        contentType:'application/json',
        id:'waitComplete',
        cellMinWidth:150,
        // even:true,
        page:{theme:'#1E9FFF'},
        cols: [[ //表头                             
          {type:'checkbox',fixed:'left'},
          {title: '<span style="color:#000;font-weight:bold;">序号</span>',minWidth:100,templet:function(d){ 
            return d.LAY_INDEX;
          }},
          {field: 'createTime', title: '<span style="color:#000;font-weight:bold;">录入日期</span>',},
          {field: 'name', title: '<span style="color:#000;font-weight:bold;">姓名</span>'},
          {field: 'assign', title: '<span style="color:#000;font-weight:bold;">指派人</span>'},
          {field: '',title:'<span style="color:#000;font-weight:bold;">操作</span>',minWidth:170,toolbar:'#waitEventBar',fixed:'right'}           //toolbar-绑定工具条
        ]],
          response:{                                         //定义后端Json格式
              statusCode:0,
              msgName:"msg",
              dataName:"data",
              countName:'amount'
          },
          request:{
              limitName:'size'
          },
          done:function(res,curr,count){
              layer.close(loadIndex);
            }
    });

    //监听信息来源
    form.on('select(inputType)',function(data){
        if(data.value == '人员'){
            waitComplete.reload({
                url:baseURL_zcw + '/expert/getList',
                where:{
                  flag: "WAIT_COMPLETE",
                },
                cols: [[ //表头                             
                  {type:'checkbox',fixed:'left'},
                  {title: '<span style="color:#000;font-weight:bold;">序号</span>',minWidth:100,fixed:'left',templet:function(d){ 
                    return d.LAY_INDEX;
                  }},
                  {field: 'createTime', title: '<span style="color:#000;font-weight:bold;">录入日期</span>',},
                  {field: 'name', title: '<span style="color:#000;font-weight:bold;">姓名</span>'},
                  {field: 'assign', title: '<span style="color:#000;font-weight:bold;">指派人</span>'},
                  {field: '',title:'<span style="color:#000;font-weight:bold;">操作</span>',minWidth:170,toolbar:'#waitEventBar',fixed:'right'}           //toolbar-绑定工具条
                ]],
            })
        }
        else if(data.value == "活动"){
            waitComplete.reload({
                url:baseURL_lbq + '/activity/getActivitiesByParams',
                where:{
                  auditStatus: 1,
                },
                cols: [[ //表头                             
                  {type:'checkbox',fixed:'left'},
                  {title: '<span style="color:#000;font-weight:bold;">序号</span>',minWidth:100,templet:function(d){ 
                    return d.LAY_INDEX;
                  }},
                  {field: 'createTime', title: '<span style="color:#000;font-weight:bold;">录入日期</span>',},
                  {field: 'communicationTheme', title: '<span style="color:#000;font-weight:bold;">交流主题</span>'},
                  {field: 'assign', title: '<span style="color:#000;font-weight:bold;">指派人</span>'},
                  {field: '',title:'<span style="color:#000;font-weight:bold;">操作</span>',minWidth:170,toolbar:'#waitEventBar',fixed:'right'}           //toolbar-绑定工具条
                ]],
            });
        }
        else if(data.value == "组织"){
            waitComplete.reload({
                url:baseURL_zcw + '/organization/getOrganizationsByParams',
                where:{
                    auditStatus: 1,
                },
                cols: [[ //表头
                    {type:'checkbox',fixed:'left'},
                    {title: '<span style="color:#000;font-weight:bold;">序号</span>',minWidth:100,templet:function(d){
                        return d.LAY_INDEX;
                    }},
                    {field: 'createTime', title: '<span style="color:#000;font-weight:bold;">录入日期</span>'},
                    {field: 'name', title: '<span style="color:#000;font-weight:bold;">组织名称</span>'},
                    {field: 'assign', title: '<span style="color:#000;font-weight:bold;">指派人</span>'},
                    {field: '',title:'<span style="color:#000;font-weight:bold;">操作</span>',minWidth:170,toolbar:'#waitEventBar',fixed:'right'}           //toolbar-绑定工具条
                ]],
            });
        }
    });

    //监听工具栏
    table.on('tool(waitComplete)',function(obj){
        var data = obj.data;
        var layEvent = obj.event;
        var tr = obj.tr;
        var communicationTheme = data.communicationTheme;
        if(data.companyEngaged!=undefined){
            IFrame.open('../../org/orgentry/orgEntry.html',obj);
        }else if(communicationTheme==undefined){    //录入类型--人员
            IFrame.open('../../person/personEntry.html',obj);
        }else{                               //录入类型--活动
            IFrame.open('../../activity/activityEntry.html',obj);
        }

    });
    
});